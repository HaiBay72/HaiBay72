# Ứng dụng Quản lý Vận tải

Ứng dụng quản lý vận tải giúp theo dõi và quản lý các hoạt động vận tải, bao gồm quản lý tài xế, nhân viên tiếp thị, phương tiện, lịch trình, và vé.

## Các tính năng chính

- **Quản lý Nhân viên**: Quản lý thông tin tài xế, nhân viên tiếp thị và người quản lý của họ
- **Quản lý Tài xế**: Quản lý thông tin tài xế, bao gồm GPLX, hạng, ngày vào làm, ghi chú
- **Quản lý Nhân viên Tiếp thị**: Quản lý thông tin nhân viên tiếp thị
- **Quản lý Phương tiện**: Quản lý thông tin phương tiện vận tải
- **Quản lý Lịch trình**: Quản lý lịch trình vận chuyển
- **Quản lý Vé**: Quản lý thông tin vé
- **Quản lý Khách hàng**: Quản lý thông tin khách hàng
- **Báo cáo**: Xem báo cáo thống kê

## Cập nhật mới

### Phiên bản 2.0.0 (21/04/2025)

1. **Thêm mục Quản lý Nhân viên**:
   - Hiển thị thông tin tài xế, nhân viên tiếp thị và người quản lý của họ
   - Chức năng gán người quản lý cho nhân viên
   - Hiển thị đầy đủ thông tin GPLX, Hạng, Ngày vào làm, Ghi chú

2. **Sửa lỗi Lịch trình**:
   - Đã sửa lỗi "không thể thêm được lịch trình"
   - Cập nhật ràng buộc khóa ngoại để tham chiếu đúng đến bảng employees

3. **Cải thiện giao diện**:
   - Giao diện tổng quan cân đối hơn
   - Thêm icon xe khách
   - Tổ chức thống kê thành hai hàng

4. **Sắp xếp ID**:
   - Sắp xếp ID của tất cả các bảng theo thứ tự tăng dần

## Hướng dẫn sử dụng

### Cài đặt

1. Giải nén file `TransportManagement.zip`
2. Chạy file `main.py` để khởi động ứng dụng

### Đăng nhập

- Tài khoản mặc định: `admin`
- Mật khẩu mặc định: `admin`

### Sử dụng mục Quản lý Nhân viên

1. Đăng nhập vào hệ thống
2. Chọn mục "Quản lý Nhân viên" từ menu bên trái
3. Xem danh sách nhân viên và thông tin người quản lý của họ
4. Sử dụng các nút "Thêm Nhân viên", "Sửa", "Xóa", "Gán Quản lý" để quản lý nhân viên

### Thêm Lịch trình

1. Đăng nhập vào hệ thống
2. Chọn mục "Lịch trình" từ menu bên trái
3. Nhấn nút "Thêm Lịch trình"
4. Điền thông tin lịch trình và nhấn "Lưu"

## Cấu trúc cơ sở dữ liệu

### Bảng employees
- id: ID nhân viên
- name: Tên nhân viên
- phone: Số điện thoại
- employee_type: Loại nhân viên (driver/marketing)
- license_number: Số GPLX (chỉ áp dụng cho tài xế)
- license_type: Hạng GPLX (chỉ áp dụng cho tài xế)
- join_date: Ngày vào làm
- status: Trạng thái
- notes: Ghi chú
- manager_id: ID người quản lý (tham chiếu đến bảng employees)

### Bảng schedules
- id: ID lịch trình
- route_id: ID tuyến đường
- vehicle_id: ID phương tiện
- driver_id: ID tài xế (tham chiếu đến bảng employees)
- departure_time: Giờ khởi hành
- arrival_time: Giờ đến
- status: Trạng thái
- notes: Ghi chú
- marketing_staff_id: ID nhân viên tiếp thị (tham chiếu đến bảng employees)

## Xử lý sự cố

### Lỗi "không thể thêm được lịch trình"
Nếu gặp lỗi này, hãy kiểm tra:
- Đảm bảo đã chọn tài xế hợp lệ từ danh sách
- Đảm bảo đã chọn phương tiện hợp lệ từ danh sách
- Đảm bảo đã chọn tuyến đường hợp lệ từ danh sách

### Lỗi không hiển thị thông tin nhân viên
Nếu thông tin nhân viên không hiển thị đầy đủ, hãy kiểm tra:
- Đảm bảo đã nhập đầy đủ thông tin khi thêm nhân viên
- Đảm bảo cơ sở dữ liệu không bị hỏng

## Liên hệ hỗ trợ

Nếu cần hỗ trợ, vui lòng liên hệ:
- Email: support@transportmanagement.com
- Điện thoại: 0123 456 789
