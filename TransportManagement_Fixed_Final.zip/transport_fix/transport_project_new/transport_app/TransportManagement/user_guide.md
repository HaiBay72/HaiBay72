# Hướng dẫn sử dụng Phần mềm Quản lý Vận tải

## Giới thiệu

Phần mềm Quản lý Vận tải là ứng dụng desktop giúp quản lý hoạt động của công ty vận tải khách liên tỉnh. Phần mềm cung cấp các chức năng quản lý xe, tài xế, lịch trình, khách hàng, vé và báo cáo thống kê.

## Cài đặt

### Yêu cầu hệ thống
- Hệ điều hành: Windows 7/8/10/11
- RAM: 2GB trở lên
- Dung lượng ổ cứng: 100MB trở lên

### Cách cài đặt
1. Giải nén file `TransportManagement.zip`
2. Chạy file `TransportManagement.exe` trong thư mục đã giải nén

## Hướng dẫn sử dụng

### Màn hình chính
Màn hình chính hiển thị tổng quan về hệ thống, bao gồm:
- Số lượng xe đang hoạt động
- Số lượng tài xế đang làm việc
- Số lượng tuyến đường
- Số lượng lịch trình
- Số lượng vé đã bán

Menu điều hướng nằm ở bên trái màn hình, cho phép truy cập vào các chức năng khác nhau của phần mềm.

### Quản lý Xe
- **Xem danh sách xe**: Hiển thị tất cả các xe trong hệ thống
- **Thêm xe mới**: Nhấn nút "Thêm Xe" và điền thông tin
- **Sửa thông tin xe**: Chọn xe trong danh sách và nhấn nút "Sửa"
- **Xóa xe**: Chọn xe trong danh sách và nhấn nút "Xóa"

### Quản lý Tài xế
- **Xem danh sách tài xế**: Hiển thị tất cả các tài xế trong hệ thống
- **Thêm tài xế mới**: Nhấn nút "Thêm Tài xế" và điền thông tin
- **Sửa thông tin tài xế**: Chọn tài xế trong danh sách và nhấn nút "Sửa"
- **Xóa tài xế**: Chọn tài xế trong danh sách và nhấn nút "Xóa"

### Quản lý Lịch trình
- **Xem danh sách lịch trình**: Hiển thị tất cả các lịch trình trong hệ thống
- **Thêm lịch trình mới**: Nhấn nút "Thêm Lịch trình" và điền thông tin
- **Sửa thông tin lịch trình**: Chọn lịch trình trong danh sách và nhấn nút "Sửa"
- **Xóa lịch trình**: Chọn lịch trình trong danh sách và nhấn nút "Xóa"

### Quản lý Khách hàng
- **Xem danh sách khách hàng**: Hiển thị tất cả các khách hàng trong hệ thống
- **Thêm khách hàng mới**: Nhấn nút "Thêm Khách hàng" và điền thông tin
- **Sửa thông tin khách hàng**: Chọn khách hàng trong danh sách và nhấn nút "Sửa"
- **Xóa khách hàng**: Chọn khách hàng trong danh sách và nhấn nút "Xóa"

### Quản lý Vé
- **Xem danh sách vé**: Hiển thị tất cả các vé trong hệ thống
- **Đặt vé mới**: Nhấn nút "Đặt Vé" và điền thông tin
- **Sửa thông tin vé**: Chọn vé trong danh sách và nhấn nút "Sửa"
- **Hủy vé**: Chọn vé trong danh sách và nhấn nút "Hủy Vé"

### Báo cáo Thống kê
- **Doanh thu theo tuyến**: Hiển thị biểu đồ và bảng doanh thu theo từng tuyến đường
- **Số lượng vé theo tuyến**: Hiển thị biểu đồ và bảng số lượng vé đã bán theo từng tuyến đường
- **Hoạt động xe**: Hiển thị biểu đồ và bảng số lượng chuyến đi của từng xe
- **Hoạt động tài xế**: Hiển thị biểu đồ và bảng số lượng chuyến đi của từng tài xế

## Xử lý sự cố

### Phần mềm không khởi động
- Đảm bảo bạn đang sử dụng hệ điều hành Windows
- Thử chạy với quyền Administrator
- Kiểm tra xem máy tính có đáp ứng yêu cầu hệ thống không

### Lỗi khi thêm/sửa dữ liệu
- Đảm bảo bạn đã điền đầy đủ các trường bắt buộc
- Kiểm tra định dạng dữ liệu nhập vào (ví dụ: ngày tháng, số điện thoại)

### Lỗi khi xóa dữ liệu
- Đảm bảo dữ liệu không đang được sử dụng bởi các bản ghi khác
- Ví dụ: Không thể xóa xe đang được sử dụng trong lịch trình

## Liên hệ hỗ trợ

Nếu bạn gặp bất kỳ vấn đề nào khi sử dụng phần mềm, vui lòng liên hệ:
- Email: support@transportmanagement.com
- Điện thoại: 0123 456 789
