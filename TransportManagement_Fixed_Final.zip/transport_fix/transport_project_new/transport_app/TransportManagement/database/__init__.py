import os
import sys

# Create __init__.py files to make directories into packages
# This helps with imports when packaging the application

# This file intentionally left empty
