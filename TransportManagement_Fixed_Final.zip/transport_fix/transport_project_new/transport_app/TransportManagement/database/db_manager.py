import os
import sys
import sqlite3

class DatabaseManager:
    def __init__(self, db_path=None):
        # Set default database path if not provided
        if db_path is None:
            # Get the directory of the current file
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # Go up one level to the project root
            project_root = os.path.dirname(current_dir)
            # Set database path in the database directory
            db_path = os.path.join(project_root, 'database', 'transport.db')
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        self.db_path = db_path
        self.connection = None
        self.cursor = None
        self.last_error = None
    
    def connect(self):
        """Connect to the SQLite database."""
        try:
            self.connection = sqlite3.connect(self.db_path)
            # Enable foreign keys
            self.connection.execute("PRAGMA foreign_keys = ON")
            # Configure connection to return rows as dictionaries
            self.connection.row_factory = sqlite3.Row
            self.cursor = self.connection.cursor()
            self.last_error = None
            return True
        except sqlite3.Error as e:
            self.last_error = f"Lỗi kết nối cơ sở dữ liệu: {e}"
            print(self.last_error)
            return False
    
    def close(self):
        """Close the database connection."""
        if self.connection:
            try:
                self.connection.commit()
                self.cursor.close()
                self.connection.close()
            except sqlite3.Error as e:
                self.last_error = f"Lỗi đóng kết nối cơ sở dữ liệu: {e}"
                print(self.last_error)
            finally:
                self.connection = None
                self.cursor = None
    
    def execute(self, query, params=None):
        """Execute a query with optional parameters."""
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            self.connection.commit()
            self.last_error = None
            return True
        except sqlite3.Error as e:
            self.last_error = f"Lỗi thực thi truy vấn: {e}"
            print(self.last_error)
            print(f"Truy vấn: {query}")
            print(f"Tham số: {params}")
            # Rollback transaction in case of error
            if self.connection:
                self.connection.rollback()
            raise Exception(self.last_error)
    
    def fetch_all(self, query, params=None):
        """Execute a query and fetch all results."""
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            result = self.cursor.fetchall()
            self.last_error = None
            return result
        except sqlite3.Error as e:
            self.last_error = f"Lỗi truy vấn dữ liệu: {e}"
            print(self.last_error)
            print(f"Truy vấn: {query}")
            print(f"Tham số: {params}")
            raise Exception(self.last_error)
    
    def fetch_one(self, query, params=None):
        """Execute a query and fetch one result."""
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            result = self.cursor.fetchone()
            self.last_error = None
            return result
        except sqlite3.Error as e:
            self.last_error = f"Lỗi truy vấn dữ liệu: {e}"
            print(self.last_error)
            print(f"Truy vấn: {query}")
            print(f"Tham số: {params}")
            raise Exception(self.last_error)
    
    def get_last_row_id(self):
        """Get the ID of the last inserted row."""
        return self.cursor.lastrowid
    
    def get_last_error(self):
        """Get the last error message."""
        return self.last_error
    
    def check_connection(self):
        """Check if the database connection is valid."""
        if not self.connection:
            return False
        
        try:
            # Try a simple query to check connection
            self.cursor.execute("SELECT 1")
            return True
        except sqlite3.Error:
            return False
