import os
import sys
import sqlite3

# Add parent directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from database.db_manager import DatabaseManager

def test_schedule_display():
    """Test the schedule display functionality to verify fixes"""
    print("Testing schedule display functionality...")
    
    # Initialize database manager
    db_manager = DatabaseManager()
    
    # Connect to database
    db_manager.connect()
    
    try:
        # Check if schedules table exists
        result = db_manager.fetch_all("SELECT name FROM sqlite_master WHERE type='table' AND name='schedules'")
        if not result:
            print("Error: schedules table does not exist!")
            return False
        
        # Check schedules table structure
        table_info = db_manager.fetch_all("PRAGMA table_info(schedules)")
        columns = [col['name'] for col in table_info]
        required_columns = ['id', 'route_id', 'vehicle_id', 'driver_id', 'marketing_staff_id', 
                           'departure_time', 'arrival_time', 'status', 'notes']
        
        missing_columns = [col for col in required_columns if col not in columns]
        if missing_columns:
            print(f"Error: Missing columns in schedules table: {missing_columns}")
            return False
        
        # Check foreign key constraints
        foreign_keys = db_manager.fetch_all("PRAGMA foreign_key_list(schedules)")
        foreign_key_refs = {fk['from']: fk['table'] for fk in foreign_keys}
        
        # Check driver_id references employees table (not drivers)
        if 'driver_id' not in foreign_key_refs:
            print("Error: No foreign key constraint for driver_id!")
            return False
        
        if foreign_key_refs.get('driver_id') != 'employees':
            print(f"Error: driver_id references {foreign_key_refs.get('driver_id')} instead of employees!")
            return False
        
        # Test query that would be used in load_data method
        try:
            schedules = db_manager.fetch_all("""
            SELECT s.id, r.name as route_name, v.license_plate as vehicle, 
                   d.name as driver, ms.name as marketing_staff,
                   s.departure_time, s.arrival_time, s.status, s.notes
            FROM schedules s
            JOIN routes r ON s.route_id = r.id
            JOIN vehicles v ON s.vehicle_id = v.id
            JOIN employees d ON s.driver_id = d.id
            LEFT JOIN employees ms ON s.marketing_staff_id = ms.id
            ORDER BY s.departure_time DESC
            LIMIT 5
            """)
            
            print(f"Successfully retrieved {len(schedules)} schedules")
            
            # Test handling of NULL values
            for schedule in schedules:
                marketing_staff = schedule['marketing_staff'] if schedule['marketing_staff'] is not None else "Chưa gán"
                notes = schedule['notes'] if schedule['notes'] is not None else ""
                print(f"Schedule {schedule['id']}: {schedule['route_name']} - {schedule['vehicle']} - {schedule['driver']} - {marketing_staff}")
            
            print("Schedule display test passed!")
            return True
            
        except Exception as e:
            print(f"Error executing schedule query: {str(e)}")
            return False
            
    except Exception as e:
        print(f"Error during test: {str(e)}")
        return False
    finally:
        # Close database connection
        db_manager.close()

if __name__ == "__main__":
    success = test_schedule_display()
    print(f"Test result: {'SUCCESS' if success else 'FAILURE'}")
    sys.exit(0 if success else 1)
