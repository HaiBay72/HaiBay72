import os
import sys
import unittest
import tkinter as tk
from unittest.mock import MagicMock, patch

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from views.employee_view import EmployeeView
from database.db_manager import DatabaseManager

class TestEmployeeManagement(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.db_manager = MagicMock(spec=DatabaseManager)
        self.current_user = {'id': 1, 'username': 'admin', 'role': 'admin'}
        
    def tearDown(self):
        self.root.destroy()
        
    def test_employee_view_initialization(self):
        employee_view = EmployeeView(self.root, self.db_manager, self.current_user)
        # Check if the title is set correctly
        title_widget = None
        for child in employee_view.winfo_children():
            for subchild in child.winfo_children():
                if hasattr(subchild, 'cget') and subchild.cget('text') == "Quản lý Nhân viên":
                    title_widget = subchild
                    break
        self.assertIsNotNone(title_widget)
        
    def test_employee_view_admin_buttons(self):
        employee_view = EmployeeView(self.root, self.db_manager, self.current_user)
        # Admin should have add, edit, delete buttons
        add_button = None
        edit_button = None
        delete_button = None
        
        for child in employee_view.winfo_children():
            for subchild in child.winfo_children():
                if hasattr(subchild, 'winfo_children'):
                    for button in subchild.winfo_children():
                        if hasattr(button, 'cget'):
                            if button.cget('text') == "Thêm Nhân viên":
                                add_button = button
                            elif button.cget('text') == "Sửa":
                                edit_button = button
                            elif button.cget('text') == "Xóa":
                                delete_button = button
        
        self.assertIsNotNone(add_button)
        self.assertIsNotNone(edit_button)
        self.assertIsNotNone(delete_button)
        
    def test_employee_view_non_admin_buttons(self):
        # Non-admin user should not have delete button
        non_admin_user = {'id': 2, 'username': 'employee', 'role': 'employee'}
        employee_view = EmployeeView(self.root, self.db_manager, non_admin_user)
        
        delete_button = None
        for child in employee_view.winfo_children():
            for subchild in child.winfo_children():
                if hasattr(subchild, 'winfo_children'):
                    for button in subchild.winfo_children():
                        if hasattr(button, 'cget') and button.cget('text') == "Xóa":
                            delete_button = button
        
        self.assertIsNone(delete_button)
        
    def test_load_data_calls_database(self):
        employee_view = EmployeeView(self.root, self.db_manager, self.current_user)
        # Mock database connection and fetch_all to return empty list
        self.db_manager.connect.return_value = True
        self.db_manager.fetch_all.return_value = []
        
        # Call load_data method
        employee_view.load_data()
        
        # Check if database methods were called
        self.db_manager.connect.assert_called_once()
        self.db_manager.fetch_all.assert_called_once()
        self.db_manager.close.assert_called_once()
        
    def test_search_employees(self):
        employee_view = EmployeeView(self.root, self.db_manager, self.current_user)
        # Mock load_data method
        employee_view.load_data = MagicMock()
        
        # Set search term and call search method
        employee_view.search_var.set("test")
        employee_view.search_employees()
        
        # Check if load_data was called with search term
        employee_view.load_data.assert_called_once_with("test")
        
if __name__ == '__main__':
    unittest.main()
