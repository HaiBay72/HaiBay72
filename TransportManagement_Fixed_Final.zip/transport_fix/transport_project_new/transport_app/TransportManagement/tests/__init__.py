import os
import sys
import unittest

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import test modules
from tests.test_login import TestLogin
from tests.test_employee_management import TestEmployeeManagement
from tests.test_schedule_management import TestScheduleManagement

if __name__ == '__main__':
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test cases
    test_suite.addTest(unittest.makeSuite(TestLogin))
    test_suite.addTest(unittest.makeSuite(TestEmployeeManagement))
    test_suite.addTest(unittest.makeSuite(TestScheduleManagement))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(test_suite)
