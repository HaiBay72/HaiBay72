import os
import sys
import unittest
import tkinter as tk
from unittest.mock import MagicMock, patch

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from views.schedule_view import ScheduleView
from database.db_manager import DatabaseManager

class TestScheduleManagement(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.db_manager = MagicMock(spec=DatabaseManager)
        self.current_user = {'id': 1, 'username': 'admin', 'role': 'admin'}
        
    def tearDown(self):
        self.root.destroy()
        
    def test_schedule_view_initialization(self):
        schedule_view = ScheduleView(self.root, self.db_manager, self.current_user)
        # Check if the title is set correctly
        title_widget = None
        for child in schedule_view.winfo_children():
            for subchild in child.winfo_children():
                if hasattr(subchild, 'cget') and subchild.cget('text') == "Quản lý Lịch trình":
                    title_widget = subchild
                    break
        self.assertIsNotNone(title_widget)
        
    def test_schedule_view_search_field(self):
        schedule_view = ScheduleView(self.root, self.db_manager, self.current_user)
        # Check if search field exists
        search_entry = None
        search_button = None
        
        for child in schedule_view.winfo_children():
            for subchild in child.winfo_children():
                if hasattr(subchild, 'winfo_children'):
                    for widget in subchild.winfo_children():
                        if isinstance(widget, tk.Entry) or (hasattr(widget, 'winfo_class') and widget.winfo_class() == 'TEntry'):
                            search_entry = widget
                        if hasattr(widget, 'cget') and widget.cget('text') == "Tìm kiếm":
                            search_button = widget
        
        self.assertIsNotNone(search_entry)
        self.assertIsNotNone(search_button)
        
    def test_schedule_view_assign_button(self):
        schedule_view = ScheduleView(self.root, self.db_manager, self.current_user)
        # Check if assign marketing staff button exists
        assign_button = None
        
        for child in schedule_view.winfo_children():
            for subchild in child.winfo_children():
                if hasattr(subchild, 'winfo_children'):
                    for button in subchild.winfo_children():
                        if hasattr(button, 'cget') and button.cget('text') == "Gán nhân viên tiếp thị":
                            assign_button = button
        
        self.assertIsNotNone(assign_button)
        
    def test_schedule_view_marketing_staff_column(self):
        schedule_view = ScheduleView(self.root, self.db_manager, self.current_user)
        # Check if marketing staff column exists in treeview
        tree = None
        
        for child in schedule_view.winfo_children():
            for subchild in child.winfo_children():
                if hasattr(subchild, 'winfo_children'):
                    for widget in subchild.winfo_children():
                        if hasattr(widget, 'heading'):
                            tree = widget
                            break
        
        self.assertIsNotNone(tree)
        self.assertIn("marketing_staff", tree["columns"])
        
    def test_load_data_calls_database(self):
        schedule_view = ScheduleView(self.root, self.db_manager, self.current_user)
        # Mock database connection and fetch_all to return empty list
        self.db_manager.connect.return_value = True
        self.db_manager.fetch_all.return_value = []
        
        # Call load_data method
        schedule_view.load_data()
        
        # Check if database methods were called
        self.db_manager.connect.assert_called_once()
        self.db_manager.fetch_all.assert_called_once()
        self.db_manager.close.assert_called_once()
        
    def test_search_schedules(self):
        schedule_view = ScheduleView(self.root, self.db_manager, self.current_user)
        # Mock load_data method
        schedule_view.load_data = MagicMock()
        
        # Set search term and call search method
        schedule_view.search_var.set("test")
        schedule_view.search_schedules()
        
        # Check if load_data was called with search term
        schedule_view.load_data.assert_called_once_with("test")
        
if __name__ == '__main__':
    unittest.main()
