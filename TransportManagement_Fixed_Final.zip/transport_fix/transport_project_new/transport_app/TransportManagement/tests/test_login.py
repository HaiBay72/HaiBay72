import os
import sys
import unittest
import tkinter as tk
from unittest.mock import MagicMock, patch

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from views.login_view import LoginView
from database.db_manager import DatabaseManager

class TestLogin(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.db_manager = MagicMock(spec=DatabaseManager)
        self.on_login_success = MagicMock()
        
    def tearDown(self):
        self.root.destroy()
        
    def test_login_view_initialization(self):
        login_view = LoginView(self.root, self.db_manager, self.on_login_success)
        self.assertEqual(self.root.title(), "Đăng nhập - Phần mềm Quản lý Vận tải")
        
    def test_login_validation_empty_fields(self):
        with patch('tkinter.messagebox.showerror') as mock_error:
            login_view = LoginView(self.root, self.db_manager, self.on_login_success)
            login_view.username_var.set("")
            login_view.password_var.set("")
            login_view.login()
            mock_error.assert_called_once()
            
    def test_login_validation_invalid_user(self):
        with patch('tkinter.messagebox.showerror') as mock_error:
            login_view = LoginView(self.root, self.db_manager, self.on_login_success)
            login_view.username_var.set("invalid_user")
            login_view.password_var.set("password")
            
            # Mock database connection and fetch_one to return None (user not found)
            self.db_manager.connect.return_value = True
            self.db_manager.fetch_one.return_value = None
            
            login_view.login()
            mock_error.assert_called_once()
            self.db_manager.fetch_one.assert_called_once()
            
    def test_login_validation_wrong_password(self):
        with patch('tkinter.messagebox.showerror') as mock_error:
            login_view = LoginView(self.root, self.db_manager, self.on_login_success)
            login_view.username_var.set("admin")
            login_view.password_var.set("wrong_password")
            
            # Mock database connection and fetch_one to return user with different password
            self.db_manager.connect.return_value = True
            self.db_manager.fetch_one.return_value = {
                'id': 1,
                'username': 'admin',
                'password': 'admin123',
                'role': 'admin',
                'employee_id': None
            }
            
            login_view.login()
            mock_error.assert_called_once()
            
    def test_login_success(self):
        login_view = LoginView(self.root, self.db_manager, self.on_login_success)
        login_view.username_var.set("admin")
        login_view.password_var.set("admin123")
        
        # Mock database connection and fetch_one to return valid user
        self.db_manager.connect.return_value = True
        user = {
            'id': 1,
            'username': 'admin',
            'password': 'admin123',
            'role': 'admin',
            'employee_id': None
        }
        self.db_manager.fetch_one.return_value = user
        
        login_view.login()
        
        # Check if on_login_success callback was called with correct parameters
        self.on_login_success.assert_called_once()
        args, kwargs = self.on_login_success.call_args
        self.assertEqual(args[0], user)  # First argument should be user
        
if __name__ == '__main__':
    unittest.main()
