import os
import sys
import sqlite3

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def migrate_database():
    """Migrate database to support separate management of drivers and marketing staff"""
    
    # Database file path
    db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'database', 'transport.db')
    
    # Connect to database
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # Begin transaction
        conn.execute("BEGIN TRANSACTION")
        
        # Check if users table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        if cursor.fetchone() is None:
            # Create users table if it doesn't exist
            cursor.execute('''
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                full_name TEXT,
                role TEXT NOT NULL,
                employee_id INTEGER,
                last_login TEXT,
                status TEXT NOT NULL,
                FOREIGN KEY (employee_id) REFERENCES employees (id)
            )
            ''')
            
            # Create default admin user
            cursor.execute('''
            INSERT INTO users (username, password, role, status, full_name)
            VALUES ('admin', '123', 'admin', 'active', 'Administrator')
            ''')
        else:
            # Update admin password if it exists
            cursor.execute('''
            UPDATE users 
            SET password = '123'
            WHERE username = 'admin'
            ''')
        
        # Check if employees table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='employees'")
        if cursor.fetchone() is None:
            # Create employees table if it doesn't exist
            cursor.execute('''
            CREATE TABLE employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT NOT NULL,
                employee_type TEXT NOT NULL,
                license_number TEXT,
                license_type TEXT,
                join_date TEXT,
                status TEXT NOT NULL,
                notes TEXT
            )
            ''')
        else:
            # Check if drivers table exists (old structure)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='drivers'")
            if cursor.fetchone() is not None:
                # Migrate data from drivers table to employees table
                cursor.execute('''
                INSERT INTO employees (name, phone, employee_type, license_number, license_type, status, notes)
                SELECT name, phone, 'driver', license_number, license_type, status, notes
                FROM drivers
                ''')
                
                # Drop drivers table
                cursor.execute("DROP TABLE drivers")
        
        # Check if schedules table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='schedules'")
        if cursor.fetchone() is not None:
            # Check if marketing_staff_id column exists in schedules table
            cursor.execute("PRAGMA table_info(schedules)")
            columns = cursor.fetchall()
            has_marketing_staff_id = any(column['name'] == 'marketing_staff_id' for column in columns)
            
            if not has_marketing_staff_id:
                # Add marketing_staff_id column to schedules table
                cursor.execute('''
                ALTER TABLE schedules
                ADD COLUMN marketing_staff_id INTEGER
                REFERENCES employees (id)
                ''')
        
        # Commit transaction
        conn.commit()
        print("Database migration completed successfully.")
        
    except Exception as e:
        # Rollback transaction in case of error
        conn.rollback()
        print(f"Error migrating database: {str(e)}")
        raise
    finally:
        # Close database connection
        conn.close()

if __name__ == "__main__":
    migrate_database()
