import os
import sys
import sqlite3

# Add parent directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

def fix_schedule_foreign_keys():
    """Fix the foreign key constraints in the schedules table"""
    print("Fixing foreign key constraints in schedules table...")
    
    # Database path
    db_path = os.path.join(parent_dir, 'database', 'transport.db')
    
    # Connect to database
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = OFF")
    cursor = conn.cursor()
    
    try:
        # Create a backup of the schedules table
        print("Creating backup of schedules table...")
        cursor.execute("CREATE TABLE IF NOT EXISTS schedules_backup AS SELECT * FROM schedules")
        
        # Get the current schema of the schedules table
        cursor.execute("PRAGMA table_info(schedules)")
        columns = cursor.fetchall()
        column_defs = [f"{col[1]} {col[2]}" for col in columns]
        
        # Drop the existing schedules table
        print("Dropping existing schedules table...")
        cursor.execute("DROP TABLE schedules")
        
        # Create a new schedules table with proper foreign key constraints
        print("Creating new schedules table with proper foreign key constraints...")
        cursor.execute("""
        CREATE TABLE schedules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id INTEGER NOT NULL,
            vehicle_id INTEGER NOT NULL,
            driver_id INTEGER NOT NULL,
            marketing_staff_id INTEGER,
            departure_time TEXT NOT NULL,
            arrival_time TEXT NOT NULL,
            status TEXT NOT NULL,
            notes TEXT,
            FOREIGN KEY (route_id) REFERENCES routes(id),
            FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
            FOREIGN KEY (driver_id) REFERENCES employees(id),
            FOREIGN KEY (marketing_staff_id) REFERENCES employees(id)
        )
        """)
        
        # Copy data from backup to new table
        print("Copying data from backup to new table...")
        cursor.execute("INSERT INTO schedules SELECT * FROM schedules_backup")
        
        # Commit changes
        conn.commit()
        print("Changes committed successfully")
        
        # Verify the new foreign key constraints
        cursor.execute("PRAGMA foreign_key_list(schedules)")
        foreign_keys = cursor.fetchall()
        
        print("New foreign key constraints:")
        for fk in foreign_keys:
            print(f"Column: {fk[3]}, References: {fk[2]}({fk[4]})")
        
        return True
    except Exception as e:
        print(f"Error fixing foreign key constraints: {str(e)}")
        conn.rollback()
        return False
    finally:
        # Close connection
        conn.close()

if __name__ == "__main__":
    success = fix_schedule_foreign_keys()
    print(f"Fix result: {'SUCCESS' if success else 'FAILURE'}")
    sys.exit(0 if success else 1)
