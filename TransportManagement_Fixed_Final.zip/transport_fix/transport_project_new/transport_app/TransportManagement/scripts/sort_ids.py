import sqlite3
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def sort_table_ids(cursor, table_name):
    """Sort IDs in a table to be sequential starting from 1"""
    print(f"Sorting IDs in {table_name} table...")
    
    # Get all rows from the table ordered by ID
    cursor.execute(f"SELECT * FROM {table_name} ORDER BY id")
    rows = cursor.fetchall()
    
    if not rows:
        print(f"No rows found in {table_name} table")
        return
    
    # Get column names
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [column[1] for column in cursor.fetchall()]
    
    # Create a temporary table
    temp_table = f"{table_name}_temp"
    columns_str = ", ".join(columns)
    placeholders = ", ".join(["?" for _ in columns])
    
    cursor.execute(f"CREATE TABLE {temp_table} AS SELECT * FROM {table_name} WHERE 0")
    
    # Insert rows into temporary table with new sequential IDs
    for new_id, row in enumerate(rows, 1):
        # Create a new row with the new ID
        new_row = list(row)
        new_row[0] = new_id  # Assuming ID is the first column
        
        cursor.execute(f"INSERT INTO {temp_table} VALUES ({placeholders})", new_row)
    
    # Drop the original table and rename the temporary table
    cursor.execute(f"DROP TABLE {table_name}")
    cursor.execute(f"ALTER TABLE {temp_table} RENAME TO {table_name}")
    
    print(f"Successfully sorted IDs in {table_name} table")

def update_foreign_keys(cursor, table_name, column_name, referenced_table):
    """Update foreign key references after ID changes"""
    print(f"Updating foreign key {column_name} in {table_name} table...")
    
    # Get all rows that have a foreign key reference
    cursor.execute(f"SELECT id, {column_name} FROM {table_name} WHERE {column_name} IS NOT NULL")
    rows = cursor.fetchall()
    
    if not rows:
        print(f"No foreign key references found in {table_name}.{column_name}")
        return
    
    # Get the mapping of old IDs to new IDs in the referenced table
    cursor.execute(f"SELECT id FROM {referenced_table} ORDER BY id")
    new_ids = [row[0] for row in cursor.fetchall()]
    
    # Update foreign key references
    for row_id, old_fk in rows:
        # Find the position of the old foreign key in the original order
        # This assumes that the relative order of IDs hasn't changed
        try:
            position = old_fk - 1  # Convert to 0-based index
            if 0 <= position < len(new_ids):
                new_fk = new_ids[position]
                cursor.execute(f"UPDATE {table_name} SET {column_name} = ? WHERE id = ?", (new_fk, row_id))
        except Exception as e:
            print(f"Error updating foreign key: {str(e)}")
    
    print(f"Successfully updated foreign key references in {table_name}.{column_name}")

def main():
    try:
        # Get the path to the database
        db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                              'database', 'transport.db')
        
        # Connect to the database
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = OFF")  # Turn off foreign keys during sorting
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
        tables = [table[0] for table in cursor.fetchall()]
        
        # Sort IDs in each table
        for table in tables:
            if table != 'sqlite_sequence':  # Skip SQLite internal tables
                sort_table_ids(cursor, table)
        
        # Update the sqlite_sequence table to reflect the new max IDs
        cursor.execute("DELETE FROM sqlite_sequence")
        for table in tables:
            if table != 'sqlite_sequence':
                cursor.execute(f"SELECT MAX(id) FROM {table}")
                max_id = cursor.fetchone()[0]
                if max_id is not None:
                    cursor.execute("INSERT INTO sqlite_sequence (name, seq) VALUES (?, ?)", (table, max_id))
        
        # Commit changes
        conn.commit()
        print("All tables have been sorted successfully")
        
        # Turn foreign keys back on
        conn.execute("PRAGMA foreign_keys = ON")
        
        # Close connection
        conn.close()
        
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main()
