import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, font

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class MainWindow:
    def __init__(self, root, db_manager, current_user, current_employee=None):
        self.root = root
        self.db_manager = db_manager
        self.current_user = current_user
        self.current_employee = current_employee
        
        # Configure style
        self.configure_style()
        
        # Create main layout
        self.create_layout()
        
        # Show default content
        self.show_dashboard()
        
    def configure_style(self):
        # Configure ttk style
        style = ttk.Style()
        
        # Configure title label style
        style.configure("Title.TLabel", font=("Arial", 18, "bold"))
        
        # Configure menu button style
        style.configure("Menu.TButton", font=("Arial", 12))
        
    def create_layout(self):
        # Clear existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Create main frame
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create sidebar frame
        self.sidebar_frame = ttk.Frame(self.main_frame, width=200, style="Sidebar.TFrame")
        self.sidebar_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        # Make sidebar frame keep its width
        self.sidebar_frame.pack_propagate(False)
        
        # Create content frame
        self.content_frame = ttk.Frame(self.main_frame)
        self.content_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Create sidebar header
        sidebar_header = ttk.Frame(self.sidebar_frame)
        sidebar_header.pack(fill=tk.X, pady=(20, 10))
        
        # Add logo or app name
        app_name = ttk.Label(sidebar_header, text="Quản lý Vận tải", font=("Arial", 14, "bold"))
        app_name.pack(side=tk.LEFT, padx=10)
        
        # Add user info
        user_frame = ttk.Frame(self.sidebar_frame)
        user_frame.pack(fill=tk.X, pady=10)
        
        # Add user icon
        user_icon = ttk.Label(user_frame, text="👤", font=("Arial", 16))
        user_icon.pack(side=tk.LEFT, padx=10)
        
        # Add username
        username = ttk.Label(user_frame, text=self.current_user['username'], font=("Arial", 12))
        username.pack(side=tk.LEFT)
        
        # Add role
        role_text = "Quản trị viên" if self.current_user['role'] == 'admin' else "Nhân viên"
        role = ttk.Label(self.sidebar_frame, text=f"Vai trò: {role_text}", font=("Arial", 10))
        role.pack(anchor=tk.W, padx=10, pady=(0, 10))
        
        # Add separator
        separator = ttk.Separator(self.sidebar_frame, orient=tk.HORIZONTAL)
        separator.pack(fill=tk.X, padx=10, pady=10)
        
        # Create menu
        self.create_menu()
        
        # Add logout button at bottom
        logout_frame = ttk.Frame(self.sidebar_frame)
        logout_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=20)
        
        logout_button = ttk.Button(logout_frame, text="Đăng xuất", command=self.logout)
        logout_button.pack(side=tk.RIGHT, padx=10)
        
    def create_menu(self):
        # Create menu frame
        menu_frame = ttk.Frame(self.sidebar_frame)
        menu_frame.pack(fill=tk.X)
        
        # Add menu buttons
        self.add_menu_button(menu_frame, "Tổng quan", self.show_dashboard)
        self.add_menu_button(menu_frame, "Khách hàng", self.show_customers)
        self.add_menu_button(menu_frame, "Quản lý Nhân viên", self.show_employee_management)
        self.add_menu_button(menu_frame, "Tài xế", self.show_drivers)
        self.add_menu_button(menu_frame, "Nhân viên Tiếp thị", self.show_marketing_staff)
        self.add_menu_button(menu_frame, "Phương tiện", self.show_vehicles)
        self.add_menu_button(menu_frame, "Lịch trình", self.show_schedules)
        self.add_menu_button(menu_frame, "Vé", self.show_tickets)
        
        # Only show reports for admin
        if self.current_user['role'] == 'admin':
            self.add_menu_button(menu_frame, "Báo cáo", self.show_reports)
            self.add_menu_button(menu_frame, "Quản lý Tài khoản", self.show_user_management)
        
    def add_menu_button(self, parent, text, command):
        button = ttk.Button(parent, text=text, command=command, style="Menu.TButton", width=25)
        button.pack(fill=tk.X, padx=5, pady=2)
        
    def clear_content(self):
        # Clear content frame
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
    def show_dashboard(self):
        # Clear content
        self.clear_content()
        
        # Add title
        title = ttk.Label(self.content_frame, text="Tổng quan", style="Title.TLabel")
        title.pack(anchor=tk.W, padx=20, pady=20)
        
        # Add welcome message
        welcome = ttk.Label(self.content_frame, text=f"Chào mừng, {self.current_user['username']}!", font=("Arial", 14))
        welcome.pack(anchor=tk.W, padx=20, pady=10)
        
        # Add last login time if available
        if 'last_login' in self.current_user and self.current_user['last_login']:
            last_login = ttk.Label(self.content_frame, text=f"Đăng nhập lần cuối: {self.current_user['last_login']}", font=("Arial", 12))
            last_login.pack(anchor=tk.W, padx=20, pady=5)
        
        # Add separator
        separator = ttk.Separator(self.content_frame, orient=tk.HORIZONTAL)
        separator.pack(fill=tk.X, padx=20, pady=10)
        
        # Add stats title
        stats_title = ttk.Label(self.content_frame, text="Thống kê hệ thống", font=("Arial", 14, "bold"))
        stats_title.pack(anchor=tk.W, padx=20, pady=10)
        
        # Add some stats
        stats_frame1 = ttk.Frame(self.content_frame)
        stats_frame1.pack(fill=tk.X, padx=20, pady=5)
        
        stats_frame2 = ttk.Frame(self.content_frame)
        stats_frame2.pack(fill=tk.X, padx=20, pady=5)
        
        # Add bus icon
        try:
            bus_icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                                        "resources", "images", "bus_icon.png")
            if os.path.exists(bus_icon_path):
                bus_icon = tk.PhotoImage(file=bus_icon_path)
                bus_icon = bus_icon.subsample(4, 4)  # Resize the image
                icon_label = ttk.Label(self.content_frame, image=bus_icon)
                icon_label.image = bus_icon  # Keep a reference
                icon_label.pack(side=tk.RIGHT, padx=20, pady=20)
        except Exception as e:
            print(f"Error loading bus icon: {str(e)}")
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Get some stats
            customers_count = self.db_manager.fetch_one("SELECT COUNT(*) as count FROM customers")
            drivers_count = self.db_manager.fetch_one("SELECT COUNT(*) as count FROM employees WHERE employee_type = 'driver'")
            marketing_count = self.db_manager.fetch_one("SELECT COUNT(*) as count FROM employees WHERE employee_type = 'marketing'")
            vehicles_count = self.db_manager.fetch_one("SELECT COUNT(*) as count FROM vehicles")
            schedules_count = self.db_manager.fetch_one("SELECT COUNT(*) as count FROM schedules")
            tickets_count = self.db_manager.fetch_one("SELECT COUNT(*) as count FROM tickets")
            
            # Create stat boxes in first row
            self.create_stat_box(stats_frame1, "Khách hàng", customers_count['count'] if customers_count else 0)
            self.create_stat_box(stats_frame1, "Tài xế", drivers_count['count'] if drivers_count else 0)
            self.create_stat_box(stats_frame1, "Nhân viên Tiếp thị", marketing_count['count'] if marketing_count else 0)
            
            # Create stat boxes in second row
            self.create_stat_box(stats_frame2, "Phương tiện", vehicles_count['count'] if vehicles_count else 0)
            self.create_stat_box(stats_frame2, "Lịch trình", schedules_count['count'] if schedules_count else 0)
            self.create_stat_box(stats_frame2, "Vé", tickets_count['count'] if tickets_count else 0)
            
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể tải dữ liệu: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
        
    def create_stat_box(self, parent, title, count):
        # Create frame
        frame = ttk.Frame(parent, borderwidth=1, relief=tk.GROOVE)
        frame.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.X, expand=True)
        
        # Add title
        title_label = ttk.Label(frame, text=title, font=("Arial", 12))
        title_label.pack(padx=10, pady=(10, 5))
        
        # Add count
        count_label = ttk.Label(frame, text=str(count), font=("Arial", 16, "bold"))
        count_label.pack(padx=10, pady=(5, 10))
        
    def show_customers(self):
        # Clear content
        self.clear_content()
        
        # Import CustomerView
        from views.customer_view import CustomerView
        
        # Create customers view
        customers_view = CustomerView(self.content_frame, self.db_manager, self.current_user)
        customers_view.pack(fill=tk.BOTH, expand=True)
    
    def show_employee_management(self):
        # Clear content
        self.clear_content()
        
        # Import EmployeeManagementView
        from views.employee_management_view import EmployeeManagementView
        
        # Create employee management view
        employee_management_view = EmployeeManagementView(self.content_frame, self.db_manager, self.current_user)
        employee_management_view.pack(fill=tk.BOTH, expand=True)
        
    def show_drivers(self):
        # Clear content
        self.clear_content()
        
        # Import DriverView
        from views.driver_view import DriverView
        
        # Create drivers view
        drivers_view = DriverView(self.content_frame, self.db_manager, self.current_user)
        drivers_view.pack(fill=tk.BOTH, expand=True)
        
    def show_marketing_staff(self):
        # Clear content
        self.clear_content()
        
        # Import MarketingStaffView
        from views.marketing_staff_view import MarketingStaffView
        
        # Create marketing staff view
        marketing_staff_view = MarketingStaffView(self.content_frame, self.db_manager, self.current_user)
        marketing_staff_view.pack(fill=tk.BOTH, expand=True)
        
    def show_vehicles(self):
        # Clear content
        self.clear_content()
        
        # Import VehicleView
        from views.vehicle_view import VehicleView
        
        # Create vehicles view
        vehicles_view = VehicleView(self.content_frame, self.db_manager)
        vehicles_view.pack(fill=tk.BOTH, expand=True)
    
    def show_schedules(self):
        # Clear content
        self.clear_content()
        
        # Import ScheduleView
        from views.schedule_view import ScheduleView
        
        # Create schedules view
        schedules_view = ScheduleView(self.content_frame, self.db_manager, self.current_user)
        schedules_view.pack(fill=tk.BOTH, expand=True)
        
    def show_tickets(self):
        # Clear content
        self.clear_content()
        
        # Import TicketView
        from views.ticket_view import TicketView
        
        # Create tickets view
        tickets_view = TicketView(self.content_frame, self.db_manager)
        tickets_view.pack(fill=tk.BOTH, expand=True)
        
    def show_reports(self):
        # Clear content
        self.clear_content()
        
        # Check if user has admin role
        if self.current_user['role'] != 'admin':
            # Show access denied message
            title = ttk.Label(self.content_frame, text="Truy cập bị từ chối", style="Title.TLabel")
            title.pack(anchor=tk.W, padx=20, pady=20)
            
            message = ttk.Label(self.content_frame, text="Bạn không có quyền truy cập báo cáo!", font=("Arial", 12))
            message.pack(anchor=tk.W, padx=20, pady=10)
            
            return
        
        # Import ReportView
        from views.report_view import ReportView
        
        # Create reports view
        reports_view = ReportView(self.content_frame, self.db_manager)
        reports_view.pack(fill=tk.BOTH, expand=True)
        
    def show_user_management(self):
        # Clear content
        self.clear_content()
        
        # Check if user has admin role
        if self.current_user['role'] != 'admin':
            # Show access denied message
            title = ttk.Label(self.content_frame, text="Truy cập bị từ chối", style="Title.TLabel")
            title.pack(anchor=tk.W, padx=20, pady=20)
            
            message = ttk.Label(self.content_frame, text="Bạn không có quyền truy cập quản lý tài khoản!", font=("Arial", 12))
            message.pack(anchor=tk.W, padx=20, pady=10)
            
            return
        
        # Import UserManagementView
        from views.user_management_view import UserManagementView
        
        # Create user management view
        user_management_view = UserManagementView(self.content_frame, self.db_manager, self.current_user)
        user_management_view.pack(fill=tk.BOTH, expand=True)
        
    def logout(self):
        # Confirm logout
        if messagebox.askyesno("Xác nhận", "Bạn có chắc chắn muốn đăng xuất?"):
            # Import and show login view
            from views.login_view import LoginView
            
            # Show login screen
            self.login_view = LoginView(self.root, self.db_manager, self.on_login_success)
    
    def on_login_success(self, user, employee):
        # Store user info
        self.current_user = user
        self.current_employee = employee
        
        # Recreate main window
        self.create_layout()
        
        # Show default content
        self.show_dashboard()
