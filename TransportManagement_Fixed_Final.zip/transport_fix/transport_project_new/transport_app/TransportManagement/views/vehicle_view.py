import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class VehicleView(ttk.Frame):
    def __init__(self, parent, db_manager):
        super().__init__(parent)
        self.parent = parent
        self.db_manager = db_manager
        
        # Configure style
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Arial", 18, "bold"))
        style.configure("Header.TButton", font=("Arial", 10, "bold"))
        
        # Create main layout
        self.create_widgets()
        
        # Load data
        self.load_data()
        
    def create_widgets(self):
        # Create header frame
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Add title
        title = ttk.Label(header_frame, text="Quản lý Xe", style="Title.TLabel")
        title.pack(side=tk.LEFT)
        
        # Add buttons
        button_frame = ttk.Frame(header_frame)
        button_frame.pack(side=tk.RIGHT)
        
        # Add button
        self.add_button = ttk.Button(button_frame, text="Thêm Xe", command=self.add_vehicle)
        self.add_button.pack(side=tk.LEFT, padx=5)
        
        # Edit button
        self.edit_button = ttk.Button(button_frame, text="Sửa", command=self.edit_vehicle)
        self.edit_button.pack(side=tk.LEFT, padx=5)
        
        # Delete button
        self.delete_button = ttk.Button(button_frame, text="Xóa", command=self.delete_vehicle)
        self.delete_button.pack(side=tk.LEFT, padx=5)
        
        # Create table
        self.create_table()
        
    def create_table(self):
        # Create a frame for the table
        table_frame = ttk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create treeview
        self.tree = ttk.Treeview(table_frame, yscrollcommand=scrollbar.set)
        
        # Configure scrollbar
        scrollbar.config(command=self.tree.yview)
        
        # Define columns
        self.tree["columns"] = ("license_plate", "model", "capacity", "year", "status", "last_maintenance", "notes")
        
        # Format columns
        self.tree.column("#0", width=50, stretch=tk.NO)
        self.tree.column("license_plate", width=100, anchor=tk.W)
        self.tree.column("model", width=150, anchor=tk.W)
        self.tree.column("capacity", width=80, anchor=tk.CENTER)
        self.tree.column("year", width=80, anchor=tk.CENTER)
        self.tree.column("status", width=100, anchor=tk.W)
        self.tree.column("last_maintenance", width=120, anchor=tk.W)
        self.tree.column("notes", width=200, anchor=tk.W)
        
        # Create headings
        self.tree.heading("#0", text="ID")
        self.tree.heading("license_plate", text="Biển số")
        self.tree.heading("model", text="Mẫu xe")
        self.tree.heading("capacity", text="Sức chứa")
        self.tree.heading("year", text="Năm SX")
        self.tree.heading("status", text="Trạng thái")
        self.tree.heading("last_maintenance", text="Bảo trì cuối")
        self.tree.heading("notes", text="Ghi chú")
        
        # Pack the treeview
        self.tree.pack(fill=tk.BOTH, expand=True)
        
    def load_data(self):
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Connect to database
        self.db_manager.connect()
        
        # Get all vehicles
        vehicles = self.db_manager.fetch_all("SELECT * FROM vehicles ORDER BY id")
        
        # Add data to treeview
        for vehicle in vehicles:
            self.tree.insert("", tk.END, text=vehicle['id'],
                           values=(vehicle['license_plate'], 
                                  vehicle['model'],
                                  vehicle['capacity'],
                                  vehicle['year'],
                                  vehicle['status'],
                                  vehicle['last_maintenance'],
                                  vehicle['notes']))
        
        # Close database connection
        self.db_manager.close()
        
    def add_vehicle(self):
        # Create dialog window
        self.dialog = tk.Toplevel(self)
        self.dialog.title("Thêm Xe Mới")
        self.dialog.geometry("400x450")
        self.dialog.resizable(False, False)
        self.dialog.transient(self)
        self.dialog.grab_set()
        
        # Create form
        self.create_vehicle_form()
        
        # Add buttons
        button_frame = ttk.Frame(self.dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_vehicle)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
        
    def create_vehicle_form(self):
        # Create form frame
        form_frame = ttk.Frame(self.dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # License plate
        ttk.Label(form_frame, text="Biển số xe:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.license_plate_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.license_plate_var, width=30).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Model
        ttk.Label(form_frame, text="Mẫu xe:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.model_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.model_var, width=30).grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Capacity
        ttk.Label(form_frame, text="Sức chứa:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.capacity_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.capacity_var, width=30).grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Year
        ttk.Label(form_frame, text="Năm sản xuất:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.year_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.year_var, width=30).grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Status
        ttk.Label(form_frame, text="Trạng thái:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.status_var = tk.StringVar()
        status_combo = ttk.Combobox(form_frame, textvariable=self.status_var, width=27)
        status_combo['values'] = ('Hoạt động', 'Bảo trì', 'Không hoạt động')
        status_combo.current(0)
        status_combo.grid(row=4, column=1, sticky=tk.W, pady=5)
        
        # Last maintenance
        ttk.Label(form_frame, text="Bảo trì cuối:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.last_maintenance_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.last_maintenance_var, width=30).grid(row=5, column=1, sticky=tk.W, pady=5)
        ttk.Label(form_frame, text="(YYYY-MM-DD)").grid(row=5, column=2, sticky=tk.W, pady=5)
        
        # Notes
        ttk.Label(form_frame, text="Ghi chú:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.notes_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.notes_var, width=30).grid(row=6, column=1, sticky=tk.W, pady=5)
        
        # Set default values for edit mode
        if hasattr(self, 'edit_id'):
            # Connect to database
            self.db_manager.connect()
            
            # Get vehicle data
            vehicle = self.db_manager.fetch_one("SELECT * FROM vehicles WHERE id = ?", (self.edit_id,))
            
            # Close database connection
            self.db_manager.close()
            
            # Set form values
            self.license_plate_var.set(vehicle['license_plate'])
            self.model_var.set(vehicle['model'])
            self.capacity_var.set(vehicle['capacity'])
            self.year_var.set(vehicle['year'])
            self.status_var.set(vehicle['status'])
            self.last_maintenance_var.set(vehicle['last_maintenance'])
            self.notes_var.set(vehicle['notes'])
        
    def save_vehicle(self):
        # Get form data
        license_plate = self.license_plate_var.get()
        model = self.model_var.get()
        capacity = self.capacity_var.get()
        year = self.year_var.get()
        status = self.status_var.get()
        last_maintenance = self.last_maintenance_var.get()
        notes = self.notes_var.get()
        
        # Validate data
        if not license_plate or not model or not capacity or not year:
            messagebox.showerror("Lỗi", "Vui lòng điền đầy đủ thông tin bắt buộc!")
            return
        
        try:
            capacity = int(capacity)
            year = int(year)
        except ValueError:
            messagebox.showerror("Lỗi", "Sức chứa và năm sản xuất phải là số!")
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if in edit mode
            if hasattr(self, 'edit_id'):
                # Update vehicle
                self.db_manager.execute("""
                UPDATE vehicles 
                SET license_plate = ?, model = ?, capacity = ?, year = ?, status = ?, last_maintenance = ?, notes = ? 
                WHERE id = ?
                """, (license_plate, model, capacity, year, status, last_maintenance, notes, self.edit_id))
                
                # Show success message
                messagebox.showinfo("Thành công", "Cập nhật thông tin xe thành công!")
                
                # Remove edit_id attribute
                delattr(self, 'edit_id')
            else:
                # Insert new vehicle
                self.db_manager.execute("""
                INSERT INTO vehicles (license_plate, model, capacity, year, status, last_maintenance, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (license_plate, model, capacity, year, status, last_maintenance, notes))
                
                # Show success message
                messagebox.showinfo("Thành công", "Thêm xe mới thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể lưu thông tin xe: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Close dialog
            self.dialog.destroy()
            
            # Reload data
            self.load_data()
        
    def edit_vehicle(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn xe cần sửa!")
            return
        
        # Get vehicle ID
        self.edit_id = int(self.tree.item(selected_item[0], "text"))
        
        # Open add dialog in edit mode
        self.add_vehicle()
        
        # Change dialog title
        self.dialog.title("Sửa Thông Tin Xe")
        
    def delete_vehicle(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn xe cần xóa!")
            return
        
        # Get vehicle ID
        vehicle_id = int(self.tree.item(selected_item[0], "text"))
        
        # Confirm deletion
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc chắn muốn xóa xe này?"):
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if vehicle is used in schedules
            schedules = self.db_manager.fetch_all("SELECT id FROM schedules WHERE vehicle_id = ?", (vehicle_id,))
            
            if schedules:
                messagebox.showerror("Lỗi", "Không thể xóa xe này vì đang được sử dụng trong lịch trình!")
                return
            
            # Delete vehicle
            self.db_manager.execute("DELETE FROM vehicles WHERE id = ?", (vehicle_id,))
            
            # Show success message
            messagebox.showinfo("Thành công", "Xóa xe thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể xóa xe: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Reload data
            self.load_data()
