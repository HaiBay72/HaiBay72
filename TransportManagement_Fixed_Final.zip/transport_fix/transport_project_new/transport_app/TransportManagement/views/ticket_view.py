import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TicketView(ttk.Frame):
    def __init__(self, parent, db_manager):
        super().__init__(parent)
        self.parent = parent
        self.db_manager = db_manager
        
        # Configure style
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Arial", 18, "bold"))
        
        # Create main layout
        self.create_widgets()
        
        # Load data
        self.load_data()
        
    def create_widgets(self):
        # Create header frame
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Add title
        title = ttk.Label(header_frame, text="Quản lý Vé", style="Title.TLabel")
        title.pack(side=tk.LEFT)
        
        # Add buttons
        button_frame = ttk.Frame(header_frame)
        button_frame.pack(side=tk.RIGHT)
        
        # Add button
        self.add_button = ttk.Button(button_frame, text="Đặt Vé", command=self.add_ticket)
        self.add_button.pack(side=tk.LEFT, padx=5)
        
        # Edit button
        self.edit_button = ttk.Button(button_frame, text="Sửa", command=self.edit_ticket)
        self.edit_button.pack(side=tk.LEFT, padx=5)
        
        # Delete button
        self.delete_button = ttk.Button(button_frame, text="Hủy Vé", command=self.delete_ticket)
        self.delete_button.pack(side=tk.LEFT, padx=5)
        
        # Create table
        self.create_table()
        
    def create_table(self):
        # Create a frame for the table
        table_frame = ttk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create treeview
        self.tree = ttk.Treeview(table_frame, yscrollcommand=scrollbar.set)
        
        # Configure scrollbar
        scrollbar.config(command=self.tree.yview)
        
        # Define columns
        self.tree["columns"] = ("schedule", "customer", "seat", "price", "booking_date", "status", "notes")
        
        # Format columns
        self.tree.column("#0", width=50, stretch=tk.NO)
        self.tree.column("schedule", width=200, anchor=tk.W)
        self.tree.column("customer", width=150, anchor=tk.W)
        self.tree.column("seat", width=80, anchor=tk.CENTER)
        self.tree.column("price", width=100, anchor=tk.E)
        self.tree.column("booking_date", width=100, anchor=tk.W)
        self.tree.column("status", width=100, anchor=tk.W)
        self.tree.column("notes", width=150, anchor=tk.W)
        
        # Create headings
        self.tree.heading("#0", text="ID")
        self.tree.heading("schedule", text="Lịch trình")
        self.tree.heading("customer", text="Khách hàng")
        self.tree.heading("seat", text="Ghế")
        self.tree.heading("price", text="Giá vé")
        self.tree.heading("booking_date", text="Ngày đặt")
        self.tree.heading("status", text="Trạng thái")
        self.tree.heading("notes", text="Ghi chú")
        
        # Pack the treeview
        self.tree.pack(fill=tk.BOTH, expand=True)
        
    def load_data(self):
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Connect to database
        self.db_manager.connect()
        
        # Get all tickets with related data
        tickets = self.db_manager.fetch_all("""
        SELECT t.id, 
               r.name || ' (' || s.departure_time || ')' as schedule_info,
               c.name as customer_name,
               t.seat_number,
               t.price,
               t.booking_date,
               t.status,
               t.notes
        FROM tickets t
        JOIN schedules s ON t.schedule_id = s.id
        JOIN routes r ON s.route_id = r.id
        JOIN customers c ON t.customer_id = c.id
        ORDER BY t.booking_date DESC
        """)
        
        # Add data to treeview
        for ticket in tickets:
            # Format price with currency
            price_formatted = f"{ticket['price']:,.0f} VND"
            
            self.tree.insert("", tk.END, text=ticket['id'],
                           values=(ticket['schedule_info'], 
                                  ticket['customer_name'],
                                  ticket['seat_number'],
                                  price_formatted,
                                  ticket['booking_date'],
                                  ticket['status'],
                                  ticket['notes']))
        
        # Close database connection
        self.db_manager.close()
        
    def add_ticket(self):
        # Create dialog window
        self.dialog = tk.Toplevel(self)
        self.dialog.title("Đặt Vé Mới")
        self.dialog.geometry("500x500")
        self.dialog.resizable(False, False)
        self.dialog.transient(self)
        self.dialog.grab_set()
        
        # Create form
        self.create_ticket_form()
        
        # Add buttons
        button_frame = ttk.Frame(self.dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_ticket)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
        
    def create_ticket_form(self):
        # Create form frame
        form_frame = ttk.Frame(self.dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Connect to database to get schedules and customers
        self.db_manager.connect()
        
        # Get schedules
        schedules = self.db_manager.fetch_all("""
        SELECT s.id, r.name || ' (' || s.departure_time || ')' as schedule_info
        FROM schedules s
        JOIN routes r ON s.route_id = r.id
        WHERE s.status IN ('Chưa khởi hành', 'Đang chạy')
        ORDER BY s.departure_time
        """)
        schedule_list = [(s['id'], s['schedule_info']) for s in schedules]
        
        # Get customers
        customers = self.db_manager.fetch_all("SELECT id, name, phone FROM customers ORDER BY name")
        customer_list = [(c['id'], f"{c['name']} ({c['phone']})") for c in customers]
        
        # Close database connection
        self.db_manager.close()
        
        # Schedule
        ttk.Label(form_frame, text="Lịch trình:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.schedule_var = tk.StringVar()
        schedule_combo = ttk.Combobox(form_frame, textvariable=self.schedule_var, width=35)
        schedule_combo['values'] = [s[1] for s in schedule_list]
        if schedule_list:
            schedule_combo.current(0)
        schedule_combo.grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Store schedule IDs
        self.schedule_ids = {s[1]: s[0] for s in schedule_list}
        
        # Customer
        ttk.Label(form_frame, text="Khách hàng:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.customer_var = tk.StringVar()
        customer_combo = ttk.Combobox(form_frame, textvariable=self.customer_var, width=35)
        customer_combo['values'] = [c[1] for c in customer_list]
        if customer_list:
            customer_combo.current(0)
        customer_combo.grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Store customer IDs
        self.customer_ids = {c[1]: c[0] for c in customer_list}
        
        # Add new customer button
        add_customer_button = ttk.Button(form_frame, text="+", width=3, 
                                       command=self.open_add_customer_dialog)
        add_customer_button.grid(row=1, column=2, padx=5)
        
        # Seat number
        ttk.Label(form_frame, text="Số ghế:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.seat_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.seat_var, width=38).grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Price
        ttk.Label(form_frame, text="Giá vé:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.price_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.price_var, width=38).grid(row=3, column=1, sticky=tk.W, pady=5)
        ttk.Label(form_frame, text="VND").grid(row=3, column=2, sticky=tk.W, pady=5)
        
        # Booking date
        ttk.Label(form_frame, text="Ngày đặt:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.booking_date_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.booking_date_var, width=38).grid(row=4, column=1, sticky=tk.W, pady=5)
        
        # Set default booking date to today
        today = datetime.now().strftime("%Y-%m-%d")
        self.booking_date_var.set(today)
        
        # Status
        ttk.Label(form_frame, text="Trạng thái:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.status_var = tk.StringVar()
        status_combo = ttk.Combobox(form_frame, textvariable=self.status_var, width=35)
        status_combo['values'] = ('Đã đặt', 'Đã thanh toán', 'Đã hủy')
        status_combo.current(0)
        status_combo.grid(row=5, column=1, sticky=tk.W, pady=5)
        
        # Notes
        ttk.Label(form_frame, text="Ghi chú:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.notes_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.notes_var, width=38).grid(row=6, column=1, sticky=tk.W, pady=5)
        
        # Set default values for edit mode
        if hasattr(self, 'edit_id'):
            # Connect to database
            self.db_manager.connect()
            
            # Get ticket data
            ticket = self.db_manager.fetch_one("""
            SELECT t.*, 
                   r.name || ' (' || s.departure_time || ')' as schedule_info,
                   c.name || ' (' || c.phone || ')' as customer_info
            FROM tickets t
            JOIN schedules s ON t.schedule_id = s.id
            JOIN routes r ON s.route_id = r.id
            JOIN customers c ON t.customer_id = c.id
            WHERE t.id = ?
            """, (self.edit_id,))
            
            # Close database connection
            self.db_manager.close()
            
            # Set form values
            self.schedule_var.set(ticket['schedule_info'])
            self.customer_var.set(ticket['customer_info'])
            self.seat_var.set(ticket['seat_number'])
            self.price_var.set(str(ticket['price']))
            self.booking_date_var.set(ticket['booking_date'])
            self.status_var.set(ticket['status'])
            self.notes_var.set(ticket['notes'] if ticket['notes'] else "")
    
    def open_add_customer_dialog(self):
        # Create dialog window
        self.customer_dialog = tk.Toplevel(self.dialog)
        self.customer_dialog.title("Thêm Khách hàng Mới")
        self.customer_dialog.geometry("400x300")
        self.customer_dialog.resizable(False, False)
        self.customer_dialog.transient(self.dialog)
        self.customer_dialog.grab_set()
        
        # Create form frame
        form_frame = ttk.Frame(self.customer_dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Name
        ttk.Label(form_frame, text="Họ tên:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.new_customer_name_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.new_customer_name_var, width=30).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Phone
        ttk.Label(form_frame, text="Điện thoại:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.new_customer_phone_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.new_customer_phone_var, width=30).grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Email
        ttk.Label(form_frame, text="Email:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.new_customer_email_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.new_customer_email_var, width=30).grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Add buttons
        button_frame = ttk.Frame(self.customer_dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_new_customer)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.customer_dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
    
    def save_new_customer(self):
        # Get form data
        name = self.new_customer_name_var.get()
        phone = self.new_customer_phone_var.get()
        email = self.new_customer_email_var.get()
        
        # Validate data
        if not name or not phone:
            messagebox.showerror("Lỗi", "Vui lòng điền đầy đủ họ tên và số điện thoại!", parent=self.customer_dialog)
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Insert new customer
            self.db_manager.execute("""
            INSERT INTO customers (name, phone, email, address, notes)
            VALUES (?, ?, ?, ?, ?)
            """, (name, phone, email, "", ""))
            
            # Get the new customer ID
            new_customer = self.db_manager.fetch_one("""
            SELECT id FROM customers WHERE name = ? AND phone = ? ORDER BY id DESC LIMIT 1
            """, (name, phone))
            
            new_customer_id = new_customer['id']
            
            # Get all customers to update the combobox
            customers = self.db_manager.fetch_all("SELECT id, name, phone FROM customers ORDER BY name")
            customer_list = [(c['id'], f"{c['name']} ({c['phone']})") for c in customers]
            
            # Update customer combobox
            self.customer_var.set(f"{name} ({phone})")
            customer_combo = self.dialog.winfo_children()[0].winfo_children()[1].winfo_children()[1]
            customer_combo['values'] = [c[1] for c in customer_list]
            
            # Update customer IDs dictionary
            self.customer_ids = {c[1]: c[0] for c in customer_list}
            
            # Show success message
            messagebox.showinfo("Thành công", "Thêm khách hàng mới thành công!", parent=self.customer_dialog)
            
            # Close dialog
            self.customer_dialog.destroy()
            
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể thêm khách hàng: {str(e)}", parent=self.customer_dialog)
        finally:
            # Close database connection
            self.db_manager.close()
        
    def save_ticket(self):
        # Get form data
        schedule = self.schedule_var.get()
        customer = self.customer_var.get()
        seat = self.seat_var.get()
        price = self.price_var.get()
        booking_date = self.booking_date_var.get()
        status = self.status_var.get()
        notes = self.notes_var.get()
        
        # Validate data
        if not schedule or not customer or not seat or not price or not booking_date:
            messagebox.showerror("Lỗi", "Vui lòng điền đầy đủ thông tin bắt buộc!")
            return
        
        # Get IDs from selected values
        try:
            schedule_id = self.schedule_ids[schedule]
            customer_id = self.customer_ids[customer]
        except KeyError:
            messagebox.showerror("Lỗi", "Vui lòng chọn lịch trình và khách hàng từ danh sách!")
            return
        
        # Validate price
        try:
            price = float(price)
        except ValueError:
            messagebox.showerror("Lỗi", "Giá vé phải là số!")
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if in edit mode
            if hasattr(self, 'edit_id'):
                # Update ticket
                self.db_manager.execute("""
                UPDATE tickets 
                SET schedule_id = ?, customer_id = ?, seat_number = ?, price = ?, booking_date = ?, status = ?, notes = ? 
                WHERE id = ?
                """, (schedule_id, customer_id, seat, price, booking_date, status, notes, self.edit_id))
                
                # Show success message
                messagebox.showinfo("Thành công", "Cập nhật thông tin vé thành công!")
                
                # Remove edit_id attribute
                delattr(self, 'edit_id')
            else:
                # Check if seat is already booked
                existing_seat = self.db_manager.fetch_one("""
                SELECT id FROM tickets 
                WHERE schedule_id = ? AND seat_number = ? AND status != 'Đã hủy'
                """, (schedule_id, seat))
                
                if existing_seat:
                    messagebox.showerror("Lỗi", f"Ghế {seat} đã được đặt cho lịch trình này!")
                    return
                
                # Insert new ticket
                self.db_manager.execute("""
                INSERT INTO tickets (schedule_id, customer_id, seat_number, price, booking_date, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (schedule_id, customer_id, seat, price, booking_date, status, notes))
                
                # Show success message
                messagebox.showinfo("Thành công", "Đặt vé mới thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể lưu thông tin vé: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Close dialog
            self.dialog.destroy()
            
            # Reload data
            self.load_data()
        
    def edit_ticket(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn vé cần sửa!")
            return
        
        # Get ticket ID
        self.edit_id = int(self.tree.item(selected_item[0], "text"))
        
        # Open add dialog in edit mode
        self.add_ticket()
        
        # Change dialog title
        self.dialog.title("Sửa Thông Tin Vé")
        
    def delete_ticket(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn vé cần hủy!")
            return
        
        # Get ticket ID
        ticket_id = int(self.tree.item(selected_item[0], "text"))
        
        # Confirm deletion
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc chắn muốn hủy vé này?"):
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Update ticket status to cancelled
            self.db_manager.execute("""
            UPDATE tickets SET status = 'Đã hủy' WHERE id = ?
            """, (ticket_id,))
            
            # Show success message
            messagebox.showinfo("Thành công", "Hủy vé thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể hủy vé: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Reload data
            self.load_data()
