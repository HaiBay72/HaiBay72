import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import re

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class CustomerView(ttk.Frame):
    def __init__(self, parent, db_manager, current_user=None):
        super().__init__(parent)
        self.parent = parent
        self.db_manager = db_manager
        self.current_user = current_user
        
        # Configure style
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Arial", 18, "bold"))
        
        # Create main layout
        self.create_widgets()
        
        # Load data
        self.load_data()
        
    def create_widgets(self):
        # Create header frame
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Add title
        title = ttk.Label(header_frame, text="Quản lý Khách hàng", style="Title.TLabel")
        title.pack(side=tk.LEFT)
        
        # Add search frame
        search_frame = ttk.Frame(header_frame)
        search_frame.pack(side=tk.RIGHT, padx=5)
        
        # Add search entry
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=20)
        search_entry.pack(side=tk.LEFT, padx=5)
        
        # Add search button
        search_button = ttk.Button(search_frame, text="Tìm kiếm", command=self.search_customers)
        search_button.pack(side=tk.LEFT)
        
        # Add buttons
        button_frame = ttk.Frame(header_frame)
        button_frame.pack(side=tk.RIGHT)
        
        # Check if user has admin role to show add/edit/delete buttons
        is_admin = self.current_user and self.current_user['role'] == 'admin'
        
        if is_admin:
            # Add button
            self.add_button = ttk.Button(button_frame, text="Thêm Khách hàng", command=self.add_customer)
            self.add_button.pack(side=tk.LEFT, padx=5)
            
            # Edit button
            self.edit_button = ttk.Button(button_frame, text="Sửa", command=self.edit_customer)
            self.edit_button.pack(side=tk.LEFT, padx=5)
            
            # Delete button
            self.delete_button = ttk.Button(button_frame, text="Xóa", command=self.delete_customer)
            self.delete_button.pack(side=tk.LEFT, padx=5)
        
        # Create table
        self.create_table()
        
    def create_table(self):
        # Create a frame for the table
        table_frame = ttk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create treeview
        self.tree = ttk.Treeview(table_frame, yscrollcommand=scrollbar.set)
        
        # Configure scrollbar
        scrollbar.config(command=self.tree.yview)
        
        # Define columns
        self.tree["columns"] = ("name", "phone", "email", "address", "notes")
        
        # Format columns
        self.tree.column("#0", width=50, stretch=tk.NO)
        self.tree.column("name", width=150, anchor=tk.W)
        self.tree.column("phone", width=100, anchor=tk.W)
        self.tree.column("email", width=150, anchor=tk.W)
        self.tree.column("address", width=200, anchor=tk.W)
        self.tree.column("notes", width=200, anchor=tk.W)
        
        # Create headings
        self.tree.heading("#0", text="ID")
        self.tree.heading("name", text="Họ tên")
        self.tree.heading("phone", text="Điện thoại")
        self.tree.heading("email", text="Email")
        self.tree.heading("address", text="Địa chỉ")
        self.tree.heading("notes", text="Ghi chú")
        
        # Pack the treeview
        self.tree.pack(fill=tk.BOTH, expand=True)
        
    def load_data(self, search_term=None):
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Get all customers
            if search_term:
                customers = self.db_manager.fetch_all("""
                SELECT * FROM customers 
                WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? OR address LIKE ?
                ORDER BY name
                """, (f"%{search_term}%", f"%{search_term}%", f"%{search_term}%", f"%{search_term}%"))
            else:
                customers = self.db_manager.fetch_all("SELECT * FROM customers ORDER BY name")
            
            # Add data to treeview
            for customer in customers:
                self.tree.insert("", tk.END, text=customer['id'],
                               values=(customer['name'], 
                                      customer['phone'],
                                      customer['email'] if customer['email'] else "",
                                      customer['address'] if customer['address'] else "",
                                      customer['notes'] if customer['notes'] else ""))
        except Exception as e:
            messagebox.showerror("Lỗi Database", f"Không thể tải dữ liệu khách hàng: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
    
    def search_customers(self):
        # Get search term
        search_term = self.search_var.get()
        
        # Load data with search term
        self.load_data(search_term)
        
    def add_customer(self):
        # Create dialog window
        self.dialog = tk.Toplevel(self)
        self.dialog.title("Thêm Khách hàng Mới")
        self.dialog.geometry("400x400")
        self.dialog.resizable(False, False)
        self.dialog.transient(self)
        self.dialog.grab_set()
        
        # Create form
        self.create_customer_form()
        
        # Add buttons
        button_frame = ttk.Frame(self.dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_customer)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
        
    def create_customer_form(self):
        # Create form frame
        form_frame = ttk.Frame(self.dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Name
        ttk.Label(form_frame, text="Họ tên:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.name_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.name_var, width=30).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Phone
        ttk.Label(form_frame, text="Điện thoại:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.phone_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.phone_var, width=30).grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Email
        ttk.Label(form_frame, text="Email:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.email_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.email_var, width=30).grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Address
        ttk.Label(form_frame, text="Địa chỉ:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.address_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.address_var, width=30).grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Notes
        ttk.Label(form_frame, text="Ghi chú:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.notes_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.notes_var, width=30).grid(row=4, column=1, sticky=tk.W, pady=5)
        
        # Set default values for edit mode
        if hasattr(self, 'edit_id'):
            # Connect to database
            self.db_manager.connect()
            
            try:
                # Get customer data
                customer = self.db_manager.fetch_one("SELECT * FROM customers WHERE id = ?", (self.edit_id,))
                
                if customer:
                    # Set form values
                    self.name_var.set(customer['name'])
                    self.phone_var.set(customer['phone'])
                    self.email_var.set(customer['email'] if customer['email'] else "")
                    self.address_var.set(customer['address'] if customer['address'] else "")
                    self.notes_var.set(customer['notes'] if customer['notes'] else "")
            except Exception as e:
                messagebox.showerror("Lỗi Database", f"Không thể tải thông tin khách hàng: {str(e)}")
            finally:
                # Close database connection
                self.db_manager.close()
        
    def save_customer(self):
        # Get form data
        name = self.name_var.get()
        phone = self.phone_var.get()
        email = self.email_var.get()
        address = self.address_var.get()
        notes = self.notes_var.get()
        
        # Validate data
        validation_errors = []
        
        # Validate required fields
        if not name:
            validation_errors.append("Họ tên không được để trống!")
        
        if not phone:
            validation_errors.append("Số điện thoại không được để trống!")
        
        # Validate phone number format
        if phone and not re.match(r'^0\d{9,10}$', phone):
            validation_errors.append("Số điện thoại không hợp lệ! Định dạng: 0XXXXXXXXX (10-11 số)")
        
        # Validate email format if provided
        if email and not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            validation_errors.append("Email không hợp lệ! Vui lòng kiểm tra lại.")
        
        # Show validation errors if any
        if validation_errors:
            messagebox.showerror("Lỗi", "\n".join(validation_errors))
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if in edit mode
            if hasattr(self, 'edit_id'):
                # Update customer
                self.db_manager.execute("""
                UPDATE customers 
                SET name = ?, phone = ?, email = ?, address = ?, notes = ? 
                WHERE id = ?
                """, (name, phone, email, address, notes, self.edit_id))
                
                # Show success message
                messagebox.showinfo("Thành công", "Cập nhật thông tin khách hàng thành công!")
                
                # Remove edit_id attribute
                delattr(self, 'edit_id')
            else:
                # Check if customer with same phone already exists
                existing = self.db_manager.fetch_one("SELECT id FROM customers WHERE phone = ?", (phone,))
                if existing:
                    messagebox.showwarning("Cảnh báo", "Khách hàng với số điện thoại này đã tồn tại!")
                    return
                
                # Insert new customer
                self.db_manager.execute("""
                INSERT INTO customers (name, phone, email, address, notes)
                VALUES (?, ?, ?, ?, ?)
                """, (name, phone, email, address, notes))
                
                # Show success message
                messagebox.showinfo("Thành công", "Thêm khách hàng mới thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể lưu thông tin khách hàng: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Close dialog
            self.dialog.destroy()
            
            # Reload data
            self.load_data()
        
    def edit_customer(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn khách hàng cần sửa!")
            return
        
        # Get customer ID
        self.edit_id = int(self.tree.item(selected_item[0], "text"))
        
        # Open add dialog in edit mode
        self.add_customer()
        
        # Change dialog title
        self.dialog.title("Sửa Thông Tin Khách hàng")
        
    def delete_customer(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn khách hàng cần xóa!")
            return
        
        # Get customer ID
        customer_id = int(self.tree.item(selected_item[0], "text"))
        
        # Confirm deletion
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc chắn muốn xóa khách hàng này?"):
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if customer has tickets
            tickets = self.db_manager.fetch_all("SELECT id FROM tickets WHERE customer_id = ?", (customer_id,))
            
            if tickets:
                messagebox.showerror("Lỗi", "Không thể xóa khách hàng này vì đã có vé được đặt!")
                return
            
            # Delete customer
            self.db_manager.execute("DELETE FROM customers WHERE id = ?", (customer_id,))
            
            # Show success message
            messagebox.showinfo("Thành công", "Xóa khách hàng thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể xóa khách hàng: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Reload data
            self.load_data()
