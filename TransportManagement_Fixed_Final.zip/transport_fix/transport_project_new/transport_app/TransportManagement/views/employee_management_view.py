import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import re
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class EmployeeManagementView(ttk.Frame):
    def __init__(self, parent, db_manager, current_user=None):
        super().__init__(parent)
        self.parent = parent
        self.db_manager = db_manager
        self.current_user = current_user
        
        # Configure style
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Arial", 18, "bold"))
        
        # Create main layout
        self.create_widgets()
        
        # Load data
        self.load_data()
        
    def create_widgets(self):
        # Create header frame
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Add title
        title = ttk.Label(header_frame, text="Quản lý Nhân viên", style="Title.TLabel")
        title.pack(side=tk.LEFT)
        
        # Add search frame
        search_frame = ttk.Frame(header_frame)
        search_frame.pack(side=tk.RIGHT, padx=5)
        
        # Add search entry
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=20)
        search_entry.pack(side=tk.LEFT, padx=5)
        
        # Add search button
        search_button = ttk.Button(search_frame, text="Tìm kiếm", command=self.search_employees)
        search_button.pack(side=tk.LEFT)
        
        # Add buttons
        button_frame = ttk.Frame(header_frame)
        button_frame.pack(side=tk.RIGHT)
        
        # Check if user has admin role to show add/edit/delete buttons
        is_admin = self.current_user and self.current_user['role'] == 'admin'
        
        if is_admin:
            # Add button
            self.add_button = ttk.Button(button_frame, text="Thêm Nhân viên", command=self.add_employee)
            self.add_button.pack(side=tk.LEFT, padx=5)
            
            # Edit button
            self.edit_button = ttk.Button(button_frame, text="Sửa", command=self.edit_employee)
            self.edit_button.pack(side=tk.LEFT, padx=5)
            
            # Delete button
            self.delete_button = ttk.Button(button_frame, text="Xóa", command=self.delete_employee)
            self.delete_button.pack(side=tk.LEFT, padx=5)
            
            # Assign Manager button
            self.assign_manager_button = ttk.Button(button_frame, text="Gán Quản lý", command=self.assign_manager)
            self.assign_manager_button.pack(side=tk.LEFT, padx=5)
        
        # Create table
        self.create_table()
        
    def create_table(self):
        # Create a frame for the table
        table_frame = ttk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create treeview
        self.tree = ttk.Treeview(table_frame, yscrollcommand=scrollbar.set)
        
        # Configure scrollbar
        scrollbar.config(command=self.tree.yview)
        
        # Define columns
        self.tree["columns"] = ("name", "phone", "employee_type", "manager", "license_info", "join_date", "status", "notes")
        
        # Format columns
        self.tree.column("#0", width=50, stretch=tk.NO)
        self.tree.column("name", width=150, anchor=tk.W)
        self.tree.column("phone", width=100, anchor=tk.W)
        self.tree.column("employee_type", width=100, anchor=tk.W)
        self.tree.column("manager", width=150, anchor=tk.W)
        self.tree.column("license_info", width=120, anchor=tk.W)
        self.tree.column("join_date", width=100, anchor=tk.W)
        self.tree.column("status", width=100, anchor=tk.W)
        self.tree.column("notes", width=150, anchor=tk.W)
        
        # Create headings
        self.tree.heading("#0", text="ID")
        self.tree.heading("name", text="Họ tên")
        self.tree.heading("phone", text="Điện thoại")
        self.tree.heading("employee_type", text="Loại nhân viên")
        self.tree.heading("manager", text="Người quản lý")
        self.tree.heading("license_info", text="Thông tin GPLX")
        self.tree.heading("join_date", text="Ngày vào làm")
        self.tree.heading("status", text="Trạng thái")
        self.tree.heading("notes", text="Ghi chú")
        
        # Pack the treeview
        self.tree.pack(fill=tk.BOTH, expand=True)
        
    def load_data(self, search_term=None):
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Add manager_id column to employees table if it doesn't exist
            try:
                self.db_manager.execute("""
                PRAGMA foreign_keys = OFF;
                ALTER TABLE employees ADD COLUMN manager_id INTEGER REFERENCES employees(id);
                PRAGMA foreign_keys = ON;
                """)
            except Exception as e:
                # Column might already exist, ignore the error
                pass
            
            # Get all employees with their manager information
            if search_term:
                employees = self.db_manager.fetch_all("""
                SELECT e.id, e.name, e.phone, e.employee_type, e.license_number, e.license_type, 
                       e.join_date, e.status, e.notes, e.manager_id, m.name as manager_name
                FROM employees e
                LEFT JOIN employees m ON e.manager_id = m.id
                WHERE e.name LIKE ? OR e.phone LIKE ? OR e.employee_type LIKE ? 
                ORDER BY e.id
                """, (f"%{search_term}%", f"%{search_term}%", f"%{search_term}%"))
            else:
                employees = self.db_manager.fetch_all("""
                SELECT e.id, e.name, e.phone, e.employee_type, e.license_number, e.license_type, 
                       e.join_date, e.status, e.notes, e.manager_id, m.name as manager_name
                FROM employees e
                LEFT JOIN employees m ON e.manager_id = m.id
                ORDER BY e.id
                """)
            
            # Add data to treeview
            for employee in employees:
                # Safely access fields with fallback to empty string
                license_number = employee['license_number'] if employee['license_number'] is not None else ''
                license_type = employee['license_type'] if employee['license_type'] is not None else ''
                join_date = employee['join_date'] if employee['join_date'] is not None else ''
                notes = employee['notes'] if employee['notes'] is not None else ''
                manager_name = employee['manager_name'] if employee['manager_name'] is not None else 'Chưa gán'
                
                # Format employee type for display
                employee_type_display = "Tài xế" if employee['employee_type'] == 'driver' else "Tiếp thị"
                
                # Format license info
                license_info = f"{license_number} ({license_type})" if license_number and license_type else ""
                
                self.tree.insert("", tk.END, text=employee['id'],
                               values=(employee['name'], 
                                      employee['phone'],
                                      employee_type_display,
                                      manager_name,
                                      license_info,
                                      join_date,
                                      employee['status'],
                                      notes))
        except Exception as e:
            messagebox.showerror("Lỗi Database", f"Không thể tải dữ liệu nhân viên: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
    
    def search_employees(self):
        # Get search term
        search_term = self.search_var.get()
        
        # Load data with search term
        self.load_data(search_term)
        
    def add_employee(self):
        # Create dialog window
        self.dialog = tk.Toplevel(self)
        self.dialog.title("Thêm Nhân viên Mới")
        self.dialog.geometry("400x550")
        self.dialog.resizable(False, False)
        self.dialog.transient(self)
        self.dialog.grab_set()
        
        # Create form
        self.create_employee_form()
        
        # Add buttons
        button_frame = ttk.Frame(self.dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_employee)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
        
    def create_employee_form(self):
        # Create form frame
        form_frame = ttk.Frame(self.dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Connect to database to get managers
        self.db_manager.connect()
        managers = self.db_manager.fetch_all("SELECT id, name FROM employees ORDER BY name")
        manager_list = [(m['id'], m['name']) for m in managers]
        self.db_manager.close()
        
        # Name
        ttk.Label(form_frame, text="Họ tên:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.name_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.name_var, width=30).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Phone
        ttk.Label(form_frame, text="Điện thoại:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.phone_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.phone_var, width=30).grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Employee type
        ttk.Label(form_frame, text="Loại nhân viên:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.employee_type_var = tk.StringVar()
        employee_type_combo = ttk.Combobox(form_frame, textvariable=self.employee_type_var, width=27)
        employee_type_combo['values'] = ('Tài xế', 'Tiếp thị')
        employee_type_combo.current(0)  # Default to driver
        employee_type_combo.grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Manager
        ttk.Label(form_frame, text="Người quản lý:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.manager_var = tk.StringVar()
        manager_combo = ttk.Combobox(form_frame, textvariable=self.manager_var, width=27)
        manager_combo['values'] = ["Chưa gán"] + [m[1] for m in manager_list]
        manager_combo.current(0)
        manager_combo.grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Store manager IDs
        self.manager_ids = {m[1]: m[0] for m in manager_list}
        
        # License number (only for drivers)
        ttk.Label(form_frame, text="Số GPLX:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.license_number_var = tk.StringVar()
        self.license_number_entry = ttk.Entry(form_frame, textvariable=self.license_number_var, width=30)
        self.license_number_entry.grid(row=4, column=1, sticky=tk.W, pady=5)
        
        # License type (only for drivers)
        ttk.Label(form_frame, text="Hạng GPLX:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.license_type_var = tk.StringVar()
        self.license_type_combo = ttk.Combobox(form_frame, textvariable=self.license_type_var, width=27)
        self.license_type_combo['values'] = ('B1', 'B2', 'C', 'D', 'E', 'F')
        self.license_type_combo.current(3)  # Default to D for bus drivers
        self.license_type_combo.grid(row=5, column=1, sticky=tk.W, pady=5)
        
        # Join date
        ttk.Label(form_frame, text="Ngày vào làm:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.join_date_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.join_date_var, width=30).grid(row=6, column=1, sticky=tk.W, pady=5)
        ttk.Label(form_frame, text="(YYYY-MM-DD)").grid(row=6, column=2, sticky=tk.W, pady=5)
        
        # Set default join date to today
        today = datetime.now().strftime("%Y-%m-%d")
        self.join_date_var.set(today)
        
        # Status
        ttk.Label(form_frame, text="Trạng thái:").grid(row=7, column=0, sticky=tk.W, pady=5)
        self.status_var = tk.StringVar()
        status_combo = ttk.Combobox(form_frame, textvariable=self.status_var, width=27)
        status_combo['values'] = ('Hoạt động', 'Nghỉ phép', 'Nghỉ việc')
        status_combo.current(0)
        status_combo.grid(row=7, column=1, sticky=tk.W, pady=5)
        
        # Notes
        ttk.Label(form_frame, text="Ghi chú:").grid(row=8, column=0, sticky=tk.W, pady=5)
        self.notes_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.notes_var, width=30).grid(row=8, column=1, sticky=tk.W, pady=5)
        
        # Bind employee type change to update form
        employee_type_combo.bind("<<ComboboxSelected>>", self.update_form_for_employee_type)
        
        # Set default values for edit mode
        if hasattr(self, 'edit_id'):
            # Connect to database
            self.db_manager.connect()
            
            try:
                # Get employee data with manager
                employee = self.db_manager.fetch_one("""
                SELECT e.*, m.name as manager_name 
                FROM employees e
                LEFT JOIN employees m ON e.manager_id = m.id
                WHERE e.id = ?
                """, (self.edit_id,))
                
                if employee:
                    # Set form values
                    self.name_var.set(employee['name'])
                    self.phone_var.set(employee['phone'])
                    
                    # Set employee type
                    if employee['employee_type'] == 'driver':
                        self.employee_type_var.set('Tài xế')
                    else:
                        self.employee_type_var.set('Tiếp thị')
                    
                    # Set manager if available
                    if 'manager_name' in employee and employee['manager_name'] is not None:
                        self.manager_var.set(employee['manager_name'])
                    else:
                        self.manager_var.set("Chưa gán")
                        
                    # Set license fields if available
                    if employee['license_number'] is not None:
                        self.license_number_var.set(employee['license_number'])
                    else:
                        self.license_number_var.set("")
                        
                    if employee['license_type'] is not None:
                        self.license_type_var.set(employee['license_type'])
                    else:
                        self.license_type_var.set("")
                    
                    # Set join_date
                    if employee['join_date'] is not None:
                        self.join_date_var.set(employee['join_date'])
                    else:
                        self.join_date_var.set(today)
                        
                    self.status_var.set(employee['status'])
                    
                    # Set notes
                    if employee['notes'] is not None:
                        self.notes_var.set(employee['notes'])
                    else:
                        self.notes_var.set("")
                        
                    # Update form for employee type
                    self.update_form_for_employee_type(None)
            except Exception as e:
                messagebox.showerror("Lỗi Database", f"Không thể tải thông tin nhân viên: {str(e)}")
            finally:
                # Close database connection
                self.db_manager.close()
    
    def update_form_for_employee_type(self, event):
        # Get employee type
        employee_type = self.employee_type_var.get()
        
        # Enable or disable license fields based on employee type
        if employee_type == 'Tài xế':
            self.license_number_entry.config(state='normal')
            self.license_type_combo.config(state='normal')
        else:
            self.license_number_entry.config(state='disabled')
            self.license_type_combo.config(state='disabled')
            
            # Clear license fields
            self.license_number_var.set("")
            self.license_type_var.set("")
        
    def save_employee(self):
        # Get form data
        name = self.name_var.get()
        phone = self.phone_var.get()
        employee_type = self.employee_type_var.get()
        manager = self.manager_var.get()
        license_number = self.license_number_var.get()
        license_type = self.license_type_var.get()
        join_date = self.join_date_var.get()
        status = self.status_var.get()
        notes = self.notes_var.get()
        
        # Convert employee type to database value
        employee_type_db = 'driver' if employee_type == 'Tài xế' else 'marketing'
        
        # Get manager ID
        manager_id = None
        if manager != "Chưa gán" and manager in self.manager_ids:
            manager_id = self.manager_ids[manager]
        
        # Validate data
        validation_errors = []
        
        # Validate required fields
        if not name:
            validation_errors.append("Họ tên không được để trống!")
        if not phone:
            validation_errors.append("Số điện thoại không được để trống!")
        if not employee_type:
            validation_errors.append("Loại nhân viên không được để trống!")
        if not status:
            validation_errors.append("Trạng thái không được để trống!")
        
        # Validate driver-specific fields
        if employee_type == 'Tài xế':
            if not license_number:
                validation_errors.append("Số GPLX không được để trống đối với tài xế!")
            if not license_type:
                validation_errors.append("Hạng GPLX không được để trống đối với tài xế!")
        
        # Validate phone number format
        if phone and not re.match(r'^0\d{9,10}$', phone):
            validation_errors.append("Số điện thoại không hợp lệ! Định dạng: 0XXXXXXXXX (10-11 số)")
        
        # Validate license number format for drivers
        if employee_type == 'Tài xế' and license_number and not re.match(r'^[A-Za-z0-9]{5,12}$', license_number):
            validation_errors.append("Số GPLX không hợp lệ! Định dạng: 5-12 ký tự chữ và số")
        
        # Validate date format if provided
        if join_date:
            try:
                datetime.strptime(join_date, '%Y-%m-%d')
            except ValueError:
                validation_errors.append("Ngày vào làm không hợp lệ! Định dạng: YYYY-MM-DD")
        
        # Show validation errors if any
        if validation_errors:
            messagebox.showerror("Lỗi", "\n".join(validation_errors))
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if in edit mode
            if hasattr(self, 'edit_id'):
                # Update employee
                self.db_manager.execute("""
                UPDATE employees 
                SET name = ?, phone = ?, employee_type = ?, manager_id = ?,
                    license_number = ?, license_type = ?, join_date = ?, status = ?, notes = ? 
                WHERE id = ?
                """, (name, phone, employee_type_db, manager_id, 
                      license_number if employee_type == 'Tài xế' else None, 
                      license_type if employee_type == 'Tài xế' else None, 
                      join_date, status, notes, self.edit_id))
                
                # Show success message
                messagebox.showinfo("Thành công", "Cập nhật thông tin nhân viên thành công!")
                
                # Remove edit_id attribute
                delattr(self, 'edit_id')
            else:
                # Insert new employee
                self.db_manager.execute("""
                INSERT INTO employees (name, phone, employee_type, manager_id, license_number, license_type, 
                                      join_date, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (name, phone, employee_type_db, manager_id,
                      license_number if employee_type == 'Tài xế' else None, 
                      license_type if employee_type == 'Tài xế' else None, 
                      join_date, status, notes))
                
                # Show success message
                messagebox.showinfo("Thành công", "Thêm nhân viên mới thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể lưu thông tin nhân viên: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Close dialog
            self.dialog.destroy()
            
            # Reload data
            self.load_data()
        
    def edit_employee(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn nhân viên cần sửa!")
            return
        
        # Get employee ID
        self.edit_id = int(self.tree.item(selected_item[0], "text"))
        
        # Open add dialog in edit mode
        self.add_employee()
        
        # Change dialog title
        self.dialog.title("Sửa Thông tin Nhân viên")
        
    def delete_employee(self):
        # Check if user has admin role
        if not self.current_user or self.current_user['role'] != 'admin':
            messagebox.showerror("Lỗi", "Bạn không có quyền xóa nhân viên!")
            return
            
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn nhân viên cần xóa!")
            return
        
        # Get employee ID
        employee_id = int(self.tree.item(selected_item[0], "text"))
        
        # Confirm deletion
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc chắn muốn xóa nhân viên này?"):
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if employee is referenced in schedules
            schedules = self.db_manager.fetch_all("""
            SELECT COUNT(*) as count FROM schedules 
            WHERE driver_id = ? OR marketing_staff_id = ?
            """, (employee_id, employee_id))
            
            if schedules and schedules[0]['count'] > 0:
                messagebox.showerror("Lỗi", "Không thể xóa nhân viên này vì đã được sử dụng trong lịch trình!")
                return
            
            # Check if employee is referenced as manager
            managers = self.db_manager.fetch_all("""
            SELECT COUNT(*) as count FROM employees 
            WHERE manager_id = ?
            """, (employee_id,))
            
            if managers and managers[0]['count'] > 0:
                messagebox.showerror("Lỗi", "Không thể xóa nhân viên này vì đang là người quản lý của nhân viên khác!")
                return
            
            # Delete employee
            self.db_manager.execute("DELETE FROM employees WHERE id = ?", (employee_id,))
            
            # Show success message
            messagebox.showinfo("Thành công", "Xóa nhân viên thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể xóa nhân viên: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Reload data
            self.load_data()
    
    def assign_manager(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn nhân viên cần gán quản lý!")
            return
        
        # Get employee ID
        employee_id = int(self.tree.item(selected_item[0], "text"))
        employee_name = self.tree.item(selected_item[0], "values")[0]
        
        # Create dialog window
        self.manager_dialog = tk.Toplevel(self)
        self.manager_dialog.title(f"Gán Quản lý cho {employee_name}")
        self.manager_dialog.geometry("350x150")
        self.manager_dialog.resizable(False, False)
        self.manager_dialog.transient(self)
        self.manager_dialog.grab_set()
        
        # Create form frame
        form_frame = ttk.Frame(self.manager_dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Connect to database to get potential managers
        self.db_manager.connect()
        
        # Get all employees except the selected one
        managers = self.db_manager.fetch_all("""
        SELECT id, name FROM employees 
        WHERE id != ? 
        ORDER BY name
        """, (employee_id,))
        
        # Get current manager
        current_manager = self.db_manager.fetch_one("""
        SELECT manager_id FROM employees WHERE id = ?
        """, (employee_id,))
        
        self.db_manager.close()
        
        manager_list = [(m['id'], m['name']) for m in managers]
        
        # Manager
        ttk.Label(form_frame, text="Người quản lý:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.manager_assign_var = tk.StringVar()
        manager_combo = ttk.Combobox(form_frame, textvariable=self.manager_assign_var, width=27)
        manager_combo['values'] = ["Chưa gán"] + [m[1] for m in manager_list]
        
        # Set current manager if available
        if current_manager and current_manager['manager_id'] is not None:
            for m in manager_list:
                if m[0] == current_manager['manager_id']:
                    self.manager_assign_var.set(m[1])
                    break
        else:
            manager_combo.current(0)
            
        manager_combo.grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Store manager IDs and employee ID
        self.manager_assign_ids = {m[1]: m[0] for m in manager_list}
        self.employee_assign_id = employee_id
        
        # Add buttons
        button_frame = ttk.Frame(self.manager_dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_manager_assignment)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.manager_dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
    
    def save_manager_assignment(self):
        # Get selected manager
        manager = self.manager_assign_var.get()
        
        # Get manager ID
        manager_id = None
        if manager != "Chưa gán" and manager in self.manager_assign_ids:
            manager_id = self.manager_assign_ids[manager]
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Update employee's manager
            self.db_manager.execute("""
            UPDATE employees SET manager_id = ? WHERE id = ?
            """, (manager_id, self.employee_assign_id))
            
            # Show success message
            messagebox.showinfo("Thành công", "Gán quản lý thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể gán quản lý: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Close dialog
            self.manager_dialog.destroy()
            
            # Reload data
            self.load_data()
