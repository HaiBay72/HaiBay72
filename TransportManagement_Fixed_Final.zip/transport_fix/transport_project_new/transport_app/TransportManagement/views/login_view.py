import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import re
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class LoginView:
    def __init__(self, root, db_manager, on_login_success):
        self.root = root
        self.db_manager = db_manager
        self.on_login_success = on_login_success
        
        # Store original window title and size
        self.original_title = self.root.title()
        self.original_geometry = self.root.geometry()
        
        # Configure login window
        self.root.title("Đăng nhập - Phần mềm Quản lý Vận tải")
        self.root.geometry("500x400")
        self.root.resizable(False, False)  # Disable resizing for login window
        
        # Create login frame
        self.create_login_frame()
        
    def create_login_frame(self):
        # Clear existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Create main frame
        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Add title
        title_label = ttk.Label(main_frame, text="ĐĂNG NHẬP HỆ THỐNG", font=("Arial", 16, "bold"))
        title_label.pack(pady=(0, 20))
        
        # Create form frame
        form_frame = ttk.Frame(main_frame)
        form_frame.pack(fill=tk.X)
        
        # Username
        ttk.Label(form_frame, text="Tên đăng nhập:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.username_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.username_var, width=30).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Password
        ttk.Label(form_frame, text="Mật khẩu:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.password_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.password_var, width=30, show="*").grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Add buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(20, 0))
        
        # Login button
        login_button = ttk.Button(button_frame, text="Đăng nhập", command=self.login)
        login_button.pack(side=tk.RIGHT, padx=5)
        
        # Exit button
        exit_button = ttk.Button(button_frame, text="Thoát", command=self.root.destroy)
        exit_button.pack(side=tk.RIGHT, padx=5)
        
        # Register button
        register_button = ttk.Button(button_frame, text="Đăng ký", command=self.show_register_frame)
        register_button.pack(side=tk.LEFT, padx=5)
        
        # Bind Enter key to login
        self.root.bind('<Return>', lambda event: self.login())
        
        # Focus on username entry
        form_frame.winfo_children()[1].focus_set()
        
    def create_register_frame(self):
        # Clear existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Create main frame
        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Add title
        title_label = ttk.Label(main_frame, text="ĐĂNG KÝ TÀI KHOẢN", font=("Arial", 16, "bold"))
        title_label.pack(pady=(0, 20))
        
        # Create form frame
        form_frame = ttk.Frame(main_frame)
        form_frame.pack(fill=tk.X)
        
        # Username
        ttk.Label(form_frame, text="Tên đăng nhập:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.reg_username_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.reg_username_var, width=30).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Password
        ttk.Label(form_frame, text="Mật khẩu:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.reg_password_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.reg_password_var, width=30, show="*").grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Confirm Password
        ttk.Label(form_frame, text="Xác nhận mật khẩu:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.reg_confirm_password_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.reg_confirm_password_var, width=30, show="*").grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Full name
        ttk.Label(form_frame, text="Họ tên:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.reg_full_name_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.reg_full_name_var, width=30).grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Connect to database to get employees
        self.db_manager.connect()
        
        try:
            # Get all employees without user accounts
            employees = self.db_manager.fetch_all("""
            SELECT e.id, e.name, e.employee_type 
            FROM employees e
            LEFT JOIN users u ON e.id = u.employee_id
            WHERE u.id IS NULL
            ORDER BY e.name
            """)
            
            # Create list of employees with type
            employee_list = []
            for employee in employees:
                employee_type = "Tài xế" if employee['employee_type'] == 'driver' else "Tiếp thị"
                employee_list.append((employee['id'], f"{employee['name']} ({employee_type})"))
        except Exception as e:
            messagebox.showerror("Lỗi Database", f"Không thể tải danh sách nhân viên: {str(e)}")
            employee_list = []
        finally:
            # Close database connection
            self.db_manager.close()
        
        # Employee
        ttk.Label(form_frame, text="Nhân viên:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.reg_employee_var = tk.StringVar()
        employee_combo = ttk.Combobox(form_frame, textvariable=self.reg_employee_var, width=27)
        employee_combo['values'] = ["Không có"] + [e[1] for e in employee_list]
        employee_combo.current(0)
        employee_combo.grid(row=4, column=1, sticky=tk.W, pady=5)
        
        # Store employee IDs
        self.employee_ids = {e[1]: e[0] for e in employee_list}
        
        # Add buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(20, 0))
        
        # Register button
        register_button = ttk.Button(button_frame, text="Đăng ký", command=self.register)
        register_button.pack(side=tk.RIGHT, padx=5)
        
        # Back button
        back_button = ttk.Button(button_frame, text="Quay lại", command=self.create_login_frame)
        back_button.pack(side=tk.RIGHT, padx=5)
        
        # Focus on username entry
        form_frame.winfo_children()[1].focus_set()
        
    def show_register_frame(self):
        # Show register frame
        self.create_register_frame()
        
    def login(self):
        # Get username and password
        username = self.username_var.get()
        password = self.password_var.get()
        
        # Validate input
        if not username or not password:
            messagebox.showerror("Lỗi", "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!")
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Get user by username
            user = self.db_manager.fetch_one("SELECT * FROM users WHERE username = ? AND status = 'active'", (username,))
            
            if not user:
                messagebox.showerror("Lỗi", "Tên đăng nhập không tồn tại hoặc tài khoản đã bị khóa!")
                return
            
            # Check password
            if user['password'] != password:
                messagebox.showerror("Lỗi", "Mật khẩu không đúng!")
                return
            
            # Update last login time
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.db_manager.execute("UPDATE users SET last_login = ? WHERE id = ?", (current_time, user['id']))
            
            # Get employee info if linked to an employee
            employee = None
            if user['employee_id']:
                employee = self.db_manager.fetch_one("SELECT * FROM employees WHERE id = ?", (user['employee_id'],))
            
            # Restore original window settings
            self.root.title(self.original_title)
            self.root.geometry(self.original_geometry)
            
            # Re-enable window resizing
            self.root.resizable(True, True)
            
            # Call login success callback with user info
            self.on_login_success(user, employee)
            
        except Exception as e:
            messagebox.showerror("Lỗi", f"Lỗi đăng nhập: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
    def register(self):
        # Get form data
        username = self.reg_username_var.get()
        password = self.reg_password_var.get()
        confirm_password = self.reg_confirm_password_var.get()
        full_name = self.reg_full_name_var.get()
        employee = self.reg_employee_var.get()
        
        # Validate data
        validation_errors = []
        
        # Validate required fields
        if not username:
            validation_errors.append("Tên đăng nhập không được để trống!")
        if not password:
            validation_errors.append("Mật khẩu không được để trống!")
        if not confirm_password:
            validation_errors.append("Xác nhận mật khẩu không được để trống!")
        
        # Validate username format
        if username and not re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
            validation_errors.append("Tên đăng nhập không hợp lệ! Chỉ được phép chữ cái, số và dấu gạch dưới, độ dài 3-20 ký tự.")
        
        # Validate password match
        if password and confirm_password and password != confirm_password:
            validation_errors.append("Mật khẩu và xác nhận mật khẩu không khớp!")
        
        # Show validation errors if any
        if validation_errors:
            messagebox.showerror("Lỗi", "\n".join(validation_errors))
            return
        
        # Get employee ID
        employee_id = None
        if employee != "Không có":
            employee_id = self.employee_ids.get(employee)
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if username already exists
            existing_user = self.db_manager.fetch_one("SELECT id FROM users WHERE username = ?", (username,))
            
            if existing_user:
                messagebox.showerror("Lỗi", "Tên đăng nhập đã tồn tại!")
                return
            
            # Insert new user with employee role
            self.db_manager.execute("""
            INSERT INTO users (username, password, full_name, role, employee_id, status)
            VALUES (?, ?, ?, 'employee', ?, 'active')
            """, (username, password, full_name, employee_id))
            
            # Show success message
            messagebox.showinfo("Thành công", "Đăng ký tài khoản thành công! Bạn có thể đăng nhập ngay bây giờ.")
            
            # Return to login frame
            self.create_login_frame()
            
            # Pre-fill username
            self.username_var.set(username)
            
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể đăng ký tài khoản: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
