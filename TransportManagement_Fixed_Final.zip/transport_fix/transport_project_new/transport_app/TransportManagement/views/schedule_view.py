import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import re
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class ScheduleView(ttk.Frame):
    def __init__(self, parent, db_manager, current_user=None):
        super().__init__(parent)
        self.parent = parent
        self.db_manager = db_manager
        self.current_user = current_user
        
        # Configure style
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Arial", 18, "bold"))
        
        # Create main layout
        self.create_widgets()
        
        # Load data
        try:
            self.load_data()
        except Exception as e:
            messagebox.showerror("Lỗi khởi tạo", f"Không thể tải dữ liệu lịch trình: {str(e)}")
            print(f"Error initializing schedule view: {str(e)}")
        
    def create_widgets(self):
        # Create header frame
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Add title
        title = ttk.Label(header_frame, text="Quản lý Lịch trình", style="Title.TLabel")
        title.pack(side=tk.LEFT)
        
        # Add search frame
        search_frame = ttk.Frame(header_frame)
        search_frame.pack(side=tk.RIGHT, padx=5)
        
        # Add search entry
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=20)
        search_entry.pack(side=tk.LEFT, padx=5)
        
        # Add search button
        search_button = ttk.Button(search_frame, text="Tìm kiếm", command=self.search_schedules)
        search_button.pack(side=tk.LEFT)
        
        # Add buttons
        button_frame = ttk.Frame(header_frame)
        button_frame.pack(side=tk.RIGHT)
        
        # Check if user has admin role to show add/edit/delete buttons
        is_admin = self.current_user and self.current_user['role'] == 'admin'
        
        # Add button
        self.add_button = ttk.Button(button_frame, text="Thêm Lịch trình", command=self.add_schedule)
        self.add_button.pack(side=tk.LEFT, padx=5)
        
        # Edit button
        self.edit_button = ttk.Button(button_frame, text="Sửa", command=self.edit_schedule)
        self.edit_button.pack(side=tk.LEFT, padx=5)
        
        # Delete button (only for admin)
        if is_admin:
            self.delete_button = ttk.Button(button_frame, text="Xóa", command=self.delete_schedule)
            self.delete_button.pack(side=tk.LEFT, padx=5)
        
        # Assign marketing staff button
        self.assign_button = ttk.Button(button_frame, text="Gán nhân viên tiếp thị", command=self.assign_marketing_staff)
        self.assign_button.pack(side=tk.LEFT, padx=5)
        
        # Create table
        self.create_table()
        
    def create_table(self):
        # Create a frame for the table
        table_frame = ttk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create treeview
        self.tree = ttk.Treeview(table_frame, yscrollcommand=scrollbar.set)
        
        # Configure scrollbar
        scrollbar.config(command=self.tree.yview)
        
        # Define columns
        self.tree["columns"] = ("route", "vehicle", "driver", "marketing_staff", "departure_time", "arrival_time", "status", "notes")
        
        # Format columns
        self.tree.column("#0", width=50, stretch=tk.NO)
        self.tree.column("route", width=150, anchor=tk.W)
        self.tree.column("vehicle", width=100, anchor=tk.W)
        self.tree.column("driver", width=120, anchor=tk.W)
        self.tree.column("marketing_staff", width=120, anchor=tk.W)
        self.tree.column("departure_time", width=120, anchor=tk.W)
        self.tree.column("arrival_time", width=120, anchor=tk.W)
        self.tree.column("status", width=100, anchor=tk.W)
        self.tree.column("notes", width=150, anchor=tk.W)
        
        # Create headings
        self.tree.heading("#0", text="ID")
        self.tree.heading("route", text="Tuyến đường")
        self.tree.heading("vehicle", text="Xe")
        self.tree.heading("driver", text="Tài xế")
        self.tree.heading("marketing_staff", text="Nhân viên tiếp thị")
        self.tree.heading("departure_time", text="Giờ khởi hành")
        self.tree.heading("arrival_time", text="Giờ đến")
        self.tree.heading("status", text="Trạng thái")
        self.tree.heading("notes", text="Ghi chú")
        
        # Pack the treeview
        self.tree.pack(fill=tk.BOTH, expand=True)
        
    def load_data(self, search_term=None):
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Get all schedules with related data
            if search_term:
                schedules = self.db_manager.fetch_all("""
                SELECT s.id, r.name as route_name, v.license_plate as vehicle, 
                       d.name as driver, ms.name as marketing_staff,
                       s.departure_time, s.arrival_time, s.status, s.notes
                FROM schedules s
                JOIN routes r ON s.route_id = r.id
                JOIN vehicles v ON s.vehicle_id = v.id
                JOIN employees d ON s.driver_id = d.id
                LEFT JOIN employees ms ON s.marketing_staff_id = ms.id
                WHERE r.name LIKE ? OR v.license_plate LIKE ? OR d.name LIKE ? 
                      OR (ms.name IS NOT NULL AND ms.name LIKE ?) OR s.status LIKE ?
                ORDER BY s.departure_time DESC
                """, (f"%{search_term}%", f"%{search_term}%", f"%{search_term}%", 
                      f"%{search_term}%", f"%{search_term}%"))
            else:
                schedules = self.db_manager.fetch_all("""
                SELECT s.id, r.name as route_name, v.license_plate as vehicle, 
                       d.name as driver, ms.name as marketing_staff,
                       s.departure_time, s.arrival_time, s.status, s.notes
                FROM schedules s
                JOIN routes r ON s.route_id = r.id
                JOIN vehicles v ON s.vehicle_id = v.id
                JOIN employees d ON s.driver_id = d.id
                LEFT JOIN employees ms ON s.marketing_staff_id = ms.id
                ORDER BY s.departure_time DESC
                """)
            
            # Add data to treeview
            for schedule in schedules:
                # Handle marketing_staff which might be None
                marketing_staff = schedule['marketing_staff'] if schedule['marketing_staff'] is not None else "Chưa gán"
                
                # Format notes to avoid displaying 'None'
                notes = schedule['notes'] if schedule['notes'] is not None else ""
                
                self.tree.insert("", tk.END, text=schedule['id'],
                               values=(schedule['route_name'], 
                                      schedule['vehicle'],
                                      schedule['driver'],
                                      marketing_staff,
                                      schedule['departure_time'],
                                      schedule['arrival_time'],
                                      schedule['status'],
                                      notes))
        except Exception as e:
            error_message = str(e)
            # Provide a more user-friendly error message
            if "unknown option" in error_message:
                error_message = "Lỗi định dạng dữ liệu. Vui lòng kiểm tra lại cấu hình cơ sở dữ liệu."
            messagebox.showerror("Lỗi Database", f"Không thể tải dữ liệu lịch trình: {error_message}")
        finally:
            # Close database connection
            self.db_manager.close()
    
    def search_schedules(self):
        # Get search term
        search_term = self.search_var.get()
        
        # Load data with search term
        self.load_data(search_term)
        
    def add_schedule(self):
        # Create dialog window
        self.dialog = tk.Toplevel(self)
        self.dialog.title("Thêm Lịch trình Mới")
        self.dialog.geometry("500x550")
        self.dialog.resizable(False, False)
        self.dialog.transient(self)
        self.dialog.grab_set()
        
        # Create form
        self.create_schedule_form()
        
        # Add buttons
        button_frame = ttk.Frame(self.dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_schedule)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
        
    def create_schedule_form(self):
        # Create form frame
        form_frame = ttk.Frame(self.dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Connect to database to get routes, vehicles, and employees
        self.db_manager.connect()
        
        # Get routes
        routes = self.db_manager.fetch_all("SELECT id, name FROM routes ORDER BY name")
        route_list = [(r['id'], r['name']) for r in routes]
        
        # Get vehicles
        vehicles = self.db_manager.fetch_all("SELECT id, license_plate, model FROM vehicles WHERE status = 'Hoạt động' ORDER BY license_plate")
        vehicle_list = [(v['id'], f"{v['license_plate']} ({v['model']})") for v in vehicles]
        
        # Get drivers (employees with type 'driver')
        drivers = self.db_manager.fetch_all("SELECT id, name FROM employees WHERE employee_type = 'driver' AND status = 'Hoạt động' ORDER BY name")
        driver_list = [(d['id'], d['name']) for d in drivers]
        
        # Get marketing staff (employees with type 'marketing')
        marketing_staff = self.db_manager.fetch_all("SELECT id, name FROM employees WHERE employee_type = 'marketing' AND status = 'Hoạt động' ORDER BY name")
        marketing_staff_list = [(m['id'], m['name']) for m in marketing_staff]
        
        # Close database connection
        self.db_manager.close()
        
        # Route
        ttk.Label(form_frame, text="Tuyến đường:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.route_var = tk.StringVar()
        route_combo = ttk.Combobox(form_frame, textvariable=self.route_var, width=35)
        route_combo['values'] = [r[1] for r in route_list]
        if route_list:
            route_combo.current(0)
        route_combo.grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Store route IDs
        self.route_ids = {r[1]: r[0] for r in route_list}
        
        # Vehicle
        ttk.Label(form_frame, text="Xe:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.vehicle_var = tk.StringVar()
        vehicle_combo = ttk.Combobox(form_frame, textvariable=self.vehicle_var, width=35)
        vehicle_combo['values'] = [v[1] for v in vehicle_list]
        if vehicle_list:
            vehicle_combo.current(0)
        vehicle_combo.grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Store vehicle IDs
        self.vehicle_ids = {v[1]: v[0] for v in vehicle_list}
        
        # Driver
        ttk.Label(form_frame, text="Tài xế:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.driver_var = tk.StringVar()
        driver_combo = ttk.Combobox(form_frame, textvariable=self.driver_var, width=35)
        driver_combo['values'] = [d[1] for d in driver_list]
        if driver_list:
            driver_combo.current(0)
        driver_combo.grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Store driver IDs
        self.driver_ids = {d[1]: d[0] for d in driver_list}
        
        # Marketing staff
        ttk.Label(form_frame, text="Nhân viên tiếp thị:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.marketing_staff_var = tk.StringVar()
        marketing_staff_combo = ttk.Combobox(form_frame, textvariable=self.marketing_staff_var, width=35)
        marketing_staff_combo['values'] = ["Chưa gán"] + [m[1] for m in marketing_staff_list]
        marketing_staff_combo.current(0)
        marketing_staff_combo.grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Store marketing staff IDs
        self.marketing_staff_ids = {m[1]: m[0] for m in marketing_staff_list}
        
        # Departure time
        ttk.Label(form_frame, text="Giờ khởi hành:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.departure_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.departure_var, width=38).grid(row=4, column=1, sticky=tk.W, pady=5)
        ttk.Label(form_frame, text="(YYYY-MM-DD HH:MM)").grid(row=4, column=2, sticky=tk.W, pady=5)
        
        # Set default departure time to now
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        self.departure_var.set(now)
        
        # Arrival time
        ttk.Label(form_frame, text="Giờ đến:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.arrival_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.arrival_var, width=38).grid(row=5, column=1, sticky=tk.W, pady=5)
        ttk.Label(form_frame, text="(YYYY-MM-DD HH:MM)").grid(row=5, column=2, sticky=tk.W, pady=5)
        
        # Status
        ttk.Label(form_frame, text="Trạng thái:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.status_var = tk.StringVar()
        status_combo = ttk.Combobox(form_frame, textvariable=self.status_var, width=35)
        status_combo['values'] = ('Chưa khởi hành', 'Đang chạy', 'Đã hoàn thành', 'Hủy')
        status_combo.current(0)
        status_combo.grid(row=6, column=1, sticky=tk.W, pady=5)
        
        # Notes
        ttk.Label(form_frame, text="Ghi chú:").grid(row=7, column=0, sticky=tk.W, pady=5)
        self.notes_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.notes_var, width=38).grid(row=7, column=1, sticky=tk.W, pady=5)
        
        # Set default values for edit mode
        if hasattr(self, 'edit_id'):
            # Connect to database
            self.db_manager.connect()
            
            # Get schedule data
            schedule = self.db_manager.fetch_one("""
            SELECT s.*, r.name as route_name, v.license_plate || ' (' || v.model || ')' as vehicle_name, 
                   d.name as driver_name, ms.name as marketing_staff_name
            FROM schedules s
            JOIN routes r ON s.route_id = r.id
            JOIN vehicles v ON s.vehicle_id = v.id
            JOIN employees d ON s.driver_id = d.id
            LEFT JOIN employees ms ON s.marketing_staff_id = ms.id
            WHERE s.id = ?
            """, (self.edit_id,))
            
            # Close database connection
            self.db_manager.close()
            
            # Set form values
            self.route_var.set(schedule['route_name'])
            self.vehicle_var.set(schedule['vehicle_name'])
            self.driver_var.set(schedule['driver_name'])
            
            # Set marketing staff if available
            if schedule['marketing_staff_name'] is not None:
                self.marketing_staff_var.set(schedule['marketing_staff_name'])
            else:
                self.marketing_staff_var.set("Chưa gán")
                
            self.departure_var.set(schedule['departure_time'])
            self.arrival_var.set(schedule['arrival_time'])
            self.status_var.set(schedule['status'])
            self.notes_var.set(schedule['notes'])
        
    def save_schedule(self):
        # Get form data
        route = self.route_var.get()
        vehicle = self.vehicle_var.get()
        driver = self.driver_var.get()
        marketing_staff = self.marketing_staff_var.get()
        departure_time = self.departure_var.get()
        arrival_time = self.arrival_var.get()
        status = self.status_var.get()
        notes = self.notes_var.get()
        
        # Validate data
        validation_errors = []
        
        # Validate required fields
        if not route or not vehicle or not driver or not departure_time or not arrival_time:
            validation_errors.append("Vui lòng điền đầy đủ thông tin bắt buộc!")
        
        # Validate datetime format
        datetime_pattern = r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$'
        
        if departure_time and not re.match(datetime_pattern, departure_time):
            validation_errors.append("Định dạng giờ khởi hành không hợp lệ! Định dạng: YYYY-MM-DD HH:MM")
        else:
            try:
                departure_datetime = datetime.strptime(departure_time, '%Y-%m-%d %H:%M')
            except ValueError:
                validation_errors.append("Giờ khởi hành không hợp lệ! Vui lòng kiểm tra lại.")
        
        if arrival_time and not re.match(datetime_pattern, arrival_time):
            validation_errors.append("Định dạng giờ đến không hợp lệ! Định dạng: YYYY-MM-DD HH:MM")
        else:
            try:
                arrival_datetime = datetime.strptime(arrival_time, '%Y-%m-%d %H:%M')
            except ValueError:
                validation_errors.append("Giờ đến không hợp lệ! Vui lòng kiểm tra lại.")
        
        # Check if arrival time is after departure time
        if not validation_errors and 'departure_datetime' in locals() and 'arrival_datetime' in locals():
            if arrival_datetime <= departure_datetime:
                validation_errors.append("Giờ đến phải sau giờ khởi hành!")
        
        # Get IDs from selected values
        try:
            if route in self.route_ids:
                route_id = self.route_ids[route]
            else:
                validation_errors.append("Vui lòng chọn tuyến đường từ danh sách!")
                
            if vehicle in self.vehicle_ids:
                vehicle_id = self.vehicle_ids[vehicle]
            else:
                validation_errors.append("Vui lòng chọn xe từ danh sách!")
                
            if driver in self.driver_ids:
                driver_id = self.driver_ids[driver]
            else:
                validation_errors.append("Vui lòng chọn tài xế từ danh sách!")
                
            # Marketing staff is optional
            marketing_staff_id = None
            if marketing_staff != "Chưa gán" and marketing_staff in self.marketing_staff_ids:
                marketing_staff_id = self.marketing_staff_ids[marketing_staff]
                
        except (KeyError, AttributeError) as e:
            validation_errors.append(f"Vui lòng chọn tuyến đường, xe và tài xế từ danh sách! Lỗi: {str(e)}")
        
        # Show validation errors if any
        if validation_errors:
            messagebox.showerror("Lỗi", "\n".join(validation_errors))
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if in edit mode
            if hasattr(self, 'edit_id'):
                # Update schedule
                self.db_manager.execute("""
                UPDATE schedules 
                SET route_id = ?, vehicle_id = ?, driver_id = ?, marketing_staff_id = ?, 
                    departure_time = ?, arrival_time = ?, status = ?, notes = ? 
                WHERE id = ?
                """, (route_id, vehicle_id, driver_id, marketing_staff_id, 
                      departure_time, arrival_time, status, notes, self.edit_id))
                
                # Show success message
                messagebox.showinfo("Thành công", "Cập nhật lịch trình thành công!")
                
                # Remove edit_id attribute
                delattr(self, 'edit_id')
            else:
                # Insert new schedule
                self.db_manager.execute("""
                INSERT INTO schedules (route_id, vehicle_id, driver_id, marketing_staff_id, 
                                      departure_time, arrival_time, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (route_id, vehicle_id, driver_id, marketing_staff_id, 
                      departure_time, arrival_time, status, notes))
                
                # Show success message
                messagebox.showinfo("Thành công", "Thêm lịch trình mới thành công!")
        except Exception as e:
            # Show error message
            error_message = str(e)
            if "no such table: main.drivers" in error_message:
                error_message = "Lỗi cấu trúc cơ sở dữ liệu: Bảng 'drivers' không tồn tại. Vui lòng liên hệ quản trị viên."
            messagebox.showerror("Lỗi", f"Không thể lưu lịch trình: {error_message}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Close dialog
            self.dialog.destroy()
            
            # Reload data
            try:
                self.load_data()
            except Exception as e:
                messagebox.showerror("Lỗi", f"Không thể tải lại dữ liệu: {str(e)}")
        
    def edit_schedule(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn lịch trình cần sửa!")
            return
        
        # Get schedule ID
        self.edit_id = int(self.tree.item(selected_item[0], "text"))
        
        # Open add dialog in edit mode
        self.add_schedule()
        
        # Change dialog title
        self.dialog.title("Sửa Lịch trình")
        
    def delete_schedule(self):
        # Check if user has admin role
        if not self.current_user or self.current_user['role'] != 'admin':
            messagebox.showerror("Lỗi", "Bạn không có quyền xóa lịch trình!")
            return
            
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn lịch trình cần xóa!")
            return
        
        # Get schedule ID
        schedule_id = int(self.tree.item(selected_item[0], "text"))
        
        # Confirm deletion
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc chắn muốn xóa lịch trình này?"):
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if schedule has tickets
            tickets = self.db_manager.fetch_all("SELECT id FROM tickets WHERE schedule_id = ?", (schedule_id,))
            
            if tickets:
                messagebox.showerror("Lỗi", "Không thể xóa lịch trình này vì đã có vé được đặt!")
                return
            
            # Delete schedule
            self.db_manager.execute("DELETE FROM schedules WHERE id = ?", (schedule_id,))
            
            # Show success message
            messagebox.showinfo("Thành công", "Xóa lịch trình thành công!")
            
            # Reorder IDs after deletion
            self.reorder_schedule_ids()
            
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể xóa lịch trình: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Reload data
            self.load_data()
    
    def assign_marketing_staff(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn lịch trình cần gán nhân viên tiếp thị!")
            return
        
        # Get schedule ID
        schedule_id = int(self.tree.item(selected_item[0], "text"))
        
        # Create dialog window
        self.assign_dialog = tk.Toplevel(self)
        self.assign_dialog.title("Gán Nhân viên Tiếp thị")
        self.assign_dialog.geometry("400x200")
        self.assign_dialog.resizable(False, False)
        self.assign_dialog.transient(self)
        self.assign_dialog.grab_set()
        
        # Create form frame
        form_frame = ttk.Frame(self.assign_dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Connect to database
        self.db_manager.connect()
        
        # Get schedule info
        schedule = self.db_manager.fetch_one("""
        SELECT s.*, r.name as route_name, ms.name as marketing_staff_name
        FROM schedules s
        JOIN routes r ON s.route_id = r.id
        LEFT JOIN employees ms ON s.marketing_staff_id = ms.id
        WHERE s.id = ?
        """, (schedule_id,))
        
        # Get marketing staff
        marketing_staff = self.db_manager.fetch_all("""
        SELECT id, name FROM employees 
        WHERE employee_type = 'marketing' AND status = 'Hoạt động' 
        ORDER BY name
        """)
        
        # Close database connection
        self.db_manager.close()
        
        # Schedule info
        ttk.Label(form_frame, text=f"Lịch trình: {schedule['route_name']}").grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=5)
        ttk.Label(form_frame, text=f"Khởi hành: {schedule['departure_time']}").grid(row=1, column=0, columnspan=2, sticky=tk.W, pady=5)
        
        # Current marketing staff
        current_staff = schedule['marketing_staff_name'] if schedule['marketing_staff_name'] else "Chưa gán"
        ttk.Label(form_frame, text=f"Nhân viên tiếp thị hiện tại: {current_staff}").grid(row=2, column=0, columnspan=2, sticky=tk.W, pady=5)
        
        # Marketing staff selection
        ttk.Label(form_frame, text="Chọn nhân viên tiếp thị:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.assign_staff_var = tk.StringVar()
        staff_combo = ttk.Combobox(form_frame, textvariable=self.assign_staff_var, width=25)
        staff_combo['values'] = ["Chưa gán"] + [m['name'] for m in marketing_staff]
        staff_combo.current(0)
        staff_combo.grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Store marketing staff IDs
        self.assign_staff_ids = {m['name']: m['id'] for m in marketing_staff}
        
        # Store schedule ID
        self.assign_schedule_id = schedule_id
        
        # Add buttons
        button_frame = ttk.Frame(self.assign_dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_marketing_staff_assignment)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.assign_dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
    
    def save_marketing_staff_assignment(self):
        # Get selected marketing staff
        staff_name = self.assign_staff_var.get()
        
        # Get marketing staff ID
        staff_id = None
        if staff_name != "Chưa gán":
            staff_id = self.assign_staff_ids.get(staff_name)
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Update schedule
            self.db_manager.execute("""
            UPDATE schedules 
            SET marketing_staff_id = ? 
            WHERE id = ?
            """, (staff_id, self.assign_schedule_id))
            
            # Show success message
            messagebox.showinfo("Thành công", "Gán nhân viên tiếp thị thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể gán nhân viên tiếp thị: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Close dialog
            self.assign_dialog.destroy()
            
            # Reload data
            self.load_data()
    
    def reorder_schedule_ids(self):
        """Reorder schedule IDs after deletion to maintain sequential order"""
        try:
            # Get all schedules ordered by ID
            schedules = self.db_manager.fetch_all("SELECT id FROM schedules ORDER BY id")
            
            # Create temporary table
            self.db_manager.execute("CREATE TABLE schedules_temp AS SELECT * FROM schedules")
            
            # Drop original table
            self.db_manager.execute("DROP TABLE schedules")
            
            # Recreate original table
            self.db_manager.execute('''
            CREATE TABLE schedules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                route_id INTEGER NOT NULL,
                vehicle_id INTEGER NOT NULL,
                driver_id INTEGER NOT NULL,
                marketing_staff_id INTEGER,
                departure_time TEXT NOT NULL,
                arrival_time TEXT NOT NULL,
                status TEXT NOT NULL,
                notes TEXT,
                FOREIGN KEY (route_id) REFERENCES routes (id),
                FOREIGN KEY (vehicle_id) REFERENCES vehicles (id),
                FOREIGN KEY (driver_id) REFERENCES employees (id),
                FOREIGN KEY (marketing_staff_id) REFERENCES employees (id)
            )
            ''')
            
            # Insert data back with new IDs
            self.db_manager.execute("""
            INSERT INTO schedules (route_id, vehicle_id, driver_id, marketing_staff_id, 
                                  departure_time, arrival_time, status, notes)
            SELECT route_id, vehicle_id, driver_id, marketing_staff_id, 
                   departure_time, arrival_time, status, notes
            FROM schedules_temp
            ORDER BY id
            """)
            
            # Drop temporary table
            self.db_manager.execute("DROP TABLE schedules_temp")
            
            # Update references in tickets table
            tickets = self.db_manager.fetch_all("SELECT id, schedule_id FROM tickets")
            
            # Create mapping of old IDs to new IDs
            id_mapping = {}
            new_schedules = self.db_manager.fetch_all("SELECT id FROM schedules ORDER BY id")
            
            for i, schedule in enumerate(schedules):
                if i < len(new_schedules):
                    id_mapping[schedule['id']] = new_schedules[i]['id']
            
            # Update tickets with new IDs
            for ticket in tickets:
                schedule_id = ticket['schedule_id']
                new_schedule_id = id_mapping.get(schedule_id, schedule_id)
                
                self.db_manager.execute("""
                UPDATE tickets 
                SET schedule_id = ? 
                WHERE id = ?
                """, (new_schedule_id, ticket['id']))
                
        except Exception as e:
            print(f"Error reordering schedule IDs: {str(e)}")
            # Rollback transaction in case of error
            if self.db_manager.connection:
                self.db_manager.connection.rollback()
