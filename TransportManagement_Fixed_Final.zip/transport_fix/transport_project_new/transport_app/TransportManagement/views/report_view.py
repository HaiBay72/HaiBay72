import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import re
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class ReportView(ttk.Frame):
    def __init__(self, parent, db_manager):
        super().__init__(parent)
        self.parent = parent
        self.db_manager = db_manager
        
        # Configure style
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Arial", 18, "bold"))
        
        # Create main layout
        self.create_widgets()
        
    def create_widgets(self):
        # Create header frame
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Add title
        title = ttk.Label(header_frame, text="Báo cáo Thống kê", style="Title.TLabel")
        title.pack(side=tk.LEFT)
        
        # Create filter frame
        filter_frame = ttk.LabelFrame(self, text="Bộ lọc")
        filter_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Report type
        ttk.Label(filter_frame, text="Loại báo cáo:").grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)
        self.report_type_var = tk.StringVar()
        report_type_combo = ttk.Combobox(filter_frame, textvariable=self.report_type_var, width=20)
        report_type_combo['values'] = ('Doanh thu theo tuyến', 'Số lượng vé theo tuyến', 'Hoạt động xe', 'Hoạt động tài xế')
        report_type_combo.current(0)
        report_type_combo.grid(row=0, column=1, sticky=tk.W, padx=10, pady=5)
        
        # Time period
        ttk.Label(filter_frame, text="Thời gian:").grid(row=0, column=2, sticky=tk.W, padx=10, pady=5)
        self.time_period_var = tk.StringVar()
        time_period_combo = ttk.Combobox(filter_frame, textvariable=self.time_period_var, width=20)
        time_period_combo['values'] = ('Hôm nay', '7 ngày qua', '30 ngày qua', 'Tháng này', 'Năm nay')
        time_period_combo.current(1)
        time_period_combo.grid(row=0, column=3, sticky=tk.W, padx=10, pady=5)
        
        # Custom date range
        ttk.Label(filter_frame, text="Hoặc khoảng thời gian tùy chỉnh:").grid(row=1, column=0, sticky=tk.W, padx=10, pady=5)
        
        # Start date
        ttk.Label(filter_frame, text="Từ ngày:").grid(row=1, column=1, sticky=tk.W, padx=10, pady=5)
        self.start_date_var = tk.StringVar()
        self.start_date_var.set(datetime.now().strftime("%Y-%m-%d"))
        start_date_entry = ttk.Entry(filter_frame, textvariable=self.start_date_var, width=15)
        start_date_entry.grid(row=1, column=2, sticky=tk.W, padx=10, pady=5)
        
        # End date
        ttk.Label(filter_frame, text="Đến ngày:").grid(row=1, column=3, sticky=tk.W, padx=10, pady=5)
        self.end_date_var = tk.StringVar()
        self.end_date_var.set(datetime.now().strftime("%Y-%m-%d"))
        end_date_entry = ttk.Entry(filter_frame, textvariable=self.end_date_var, width=15)
        end_date_entry.grid(row=1, column=4, sticky=tk.W, padx=10, pady=5)
        
        # Use custom date checkbox
        self.use_custom_date_var = tk.BooleanVar()
        self.use_custom_date_var.set(False)
        use_custom_date_check = ttk.Checkbutton(filter_frame, text="Sử dụng khoảng thời gian tùy chỉnh", 
                                              variable=self.use_custom_date_var)
        use_custom_date_check.grid(row=2, column=0, columnspan=3, sticky=tk.W, padx=10, pady=5)
        
        # Generate button
        generate_button = ttk.Button(filter_frame, text="Tạo báo cáo", command=self.generate_report)
        generate_button.grid(row=2, column=4, padx=10, pady=5)
        
        # Create content frame
        self.content_frame = ttk.Frame(self)
        self.content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create initial report
        self.generate_report()
        
    def generate_report(self):
        # Clear content frame
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        # Get report type and time period
        report_type = self.report_type_var.get()
        
        # Validate and get date range
        try:
            if self.use_custom_date_var.get():
                # Validate custom date format
                start_date_str = self.start_date_var.get()
                end_date_str = self.end_date_var.get()
                
                date_pattern = r'^\d{4}-\d{2}-\d{2}$'
                if not re.match(date_pattern, start_date_str) or not re.match(date_pattern, end_date_str):
                    messagebox.showerror("Lỗi", "Định dạng ngày không hợp lệ! Vui lòng sử dụng định dạng YYYY-MM-DD")
                    return
                
                try:
                    start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                    end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
                    
                    # Validate date range
                    if end_date < start_date:
                        messagebox.showerror("Lỗi", "Ngày kết thúc phải sau ngày bắt đầu!")
                        return
                    
                    if (end_date - start_date).days > 365:
                        messagebox.showwarning("Cảnh báo", "Khoảng thời gian quá dài có thể làm chậm báo cáo!")
                except ValueError:
                    messagebox.showerror("Lỗi", "Ngày không hợp lệ! Vui lòng kiểm tra lại.")
                    return
            else:
                # Calculate date range from predefined periods
                time_period = self.time_period_var.get()
                today = datetime.now().date()
                
                if time_period == 'Hôm nay':
                    start_date = today
                elif time_period == '7 ngày qua':
                    start_date = today - timedelta(days=7)
                elif time_period == '30 ngày qua':
                    start_date = today - timedelta(days=30)
                elif time_period == 'Tháng này':
                    start_date = today.replace(day=1)
                elif time_period == 'Năm nay':
                    start_date = today.replace(month=1, day=1)
                
                end_date = today
                
                # Update custom date fields for consistency
                self.start_date_var.set(start_date.strftime('%Y-%m-%d'))
                self.end_date_var.set(end_date.strftime('%Y-%m-%d'))
            
            # Format dates for SQL query
            start_date_str = start_date.strftime('%Y-%m-%d')
            end_date_str = end_date.strftime('%Y-%m-%d')
            
            # Connect to database
            self.db_manager.connect()
            
            # Generate report based on type
            if report_type == 'Doanh thu theo tuyến':
                self.generate_revenue_by_route_report(start_date_str, end_date_str)
            elif report_type == 'Số lượng vé theo tuyến':
                self.generate_tickets_by_route_report(start_date_str, end_date_str)
            elif report_type == 'Hoạt động xe':
                self.generate_vehicle_activity_report(start_date_str, end_date_str)
            elif report_type == 'Hoạt động tài xế':
                self.generate_driver_activity_report(start_date_str, end_date_str)
            
            # Close database connection
            self.db_manager.close()
            
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể tạo báo cáo: {str(e)}")
            # Create error message in content frame
            error_label = ttk.Label(self.content_frame, text=f"Lỗi khi tạo báo cáo: {str(e)}", 
                                  foreground="red", font=("Arial", 12))
            error_label.pack(pady=20)
        
    def generate_revenue_by_route_report(self, start_date, end_date):
        # Get revenue by route
        data = self.db_manager.fetch_all("""
        SELECT r.name as route, SUM(t.price) as revenue
        FROM tickets t
        JOIN schedules s ON t.schedule_id = s.id
        JOIN routes r ON s.route_id = r.id
        WHERE t.booking_date BETWEEN ? AND ?
        AND t.status != 'Đã hủy'
        GROUP BY r.name
        ORDER BY revenue DESC
        """, (start_date, end_date))
        
        # Create report title
        title = ttk.Label(self.content_frame, text=f"Báo cáo Doanh thu theo Tuyến ({start_date} đến {end_date})", 
                         font=("Arial", 14, "bold"))
        title.pack(pady=10)
        
        # Create table frame
        table_frame = ttk.Frame(self.content_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, padx=10, pady=10)
        
        # Create table
        columns = ("route", "revenue")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        
        # Format columns
        tree.column("route", width=200, anchor=tk.W)
        tree.column("revenue", width=150, anchor=tk.E)
        
        # Create headings
        tree.heading("route", text="Tuyến đường")
        tree.heading("revenue", text="Doanh thu (VND)")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Add data to table
        total_revenue = 0
        for item in data:
            revenue = item['revenue']
            total_revenue += revenue
            tree.insert("", tk.END, values=(item['route'], f"{revenue:,.0f}"))
        
        # Add total row
        tree.insert("", tk.END, values=("TỔNG CỘNG", f"{total_revenue:,.0f}"))
        
        # Create chart frame
        chart_frame = ttk.Frame(self.content_frame)
        chart_frame.pack(fill=tk.BOTH, expand=True, side=tk.RIGHT, padx=10, pady=10)
        
        # Create chart
        if data:
            try:
                fig, ax = plt.subplots(figsize=(6, 4))
                
                routes = [item['route'] for item in data]
                revenues = [item['revenue'] for item in data]
                
                # Create bar chart
                bars = ax.bar(routes, revenues)
                
                # Add labels
                ax.set_title('Doanh thu theo Tuyến')
                ax.set_xlabel('Tuyến đường')
                ax.set_ylabel('Doanh thu (VND)')
                
                # Rotate x-axis labels
                plt.xticks(rotation=45, ha='right')
                
                # Format y-axis labels
                ax.get_yaxis().set_major_formatter(
                    plt.FuncFormatter(lambda x, loc: "{:,}".format(int(x))))
                
                # Add value labels on top of bars
                for bar in bars:
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2., height,
                           f'{height:,.0f}',
                           ha='center', va='bottom', rotation=0)
                
                # Adjust layout
                plt.tight_layout()
                
                # Create canvas
                canvas = FigureCanvasTkAgg(fig, master=chart_frame)
                canvas.draw()
                canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            except Exception as e:
                error_label = ttk.Label(chart_frame, text=f"Không thể tạo biểu đồ: {str(e)}", 
                                      foreground="red")
                error_label.pack(pady=20)
        else:
            no_data_label = ttk.Label(chart_frame, text="Không có dữ liệu để hiển thị biểu đồ", 
                                    font=("Arial", 12))
            no_data_label.pack(pady=20)
        
    def generate_tickets_by_route_report(self, start_date, end_date):
        # Get tickets by route
        data = self.db_manager.fetch_all("""
        SELECT r.name as route, COUNT(t.id) as ticket_count
        FROM tickets t
        JOIN schedules s ON t.schedule_id = s.id
        JOIN routes r ON s.route_id = r.id
        WHERE t.booking_date BETWEEN ? AND ?
        AND t.status != 'Đã hủy'
        GROUP BY r.name
        ORDER BY ticket_count DESC
        """, (start_date, end_date))
        
        # Create report title
        title = ttk.Label(self.content_frame, text=f"Báo cáo Số lượng Vé theo Tuyến ({start_date} đến {end_date})", 
                         font=("Arial", 14, "bold"))
        title.pack(pady=10)
        
        # Create table frame
        table_frame = ttk.Frame(self.content_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, padx=10, pady=10)
        
        # Create table
        columns = ("route", "ticket_count")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        
        # Format columns
        tree.column("route", width=200, anchor=tk.W)
        tree.column("ticket_count", width=150, anchor=tk.E)
        
        # Create headings
        tree.heading("route", text="Tuyến đường")
        tree.heading("ticket_count", text="Số lượng vé")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Add data to table
        total_tickets = 0
        for item in data:
            ticket_count = item['ticket_count']
            total_tickets += ticket_count
            tree.insert("", tk.END, values=(item['route'], ticket_count))
        
        # Add total row
        tree.insert("", tk.END, values=("TỔNG CỘNG", total_tickets))
        
        # Create chart frame
        chart_frame = ttk.Frame(self.content_frame)
        chart_frame.pack(fill=tk.BOTH, expand=True, side=tk.RIGHT, padx=10, pady=10)
        
        # Create chart
        if data:
            try:
                fig, ax = plt.subplots(figsize=(6, 4))
                
                routes = [item['route'] for item in data]
                ticket_counts = [item['ticket_count'] for item in data]
                
                # Create pie chart
                ax.pie(ticket_counts, labels=routes, autopct='%1.1f%%', startangle=90)
                ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
                
                # Add title
                ax.set_title('Phân bố Vé theo Tuyến')
                
                # Adjust layout
                plt.tight_layout()
                
                # Create canvas
                canvas = FigureCanvasTkAgg(fig, master=chart_frame)
                canvas.draw()
                canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            except Exception as e:
                error_label = ttk.Label(chart_frame, text=f"Không thể tạo biểu đồ: {str(e)}", 
                                      foreground="red")
                error_label.pack(pady=20)
        else:
            no_data_label = ttk.Label(chart_frame, text="Không có dữ liệu để hiển thị biểu đồ", 
                                    font=("Arial", 12))
            no_data_label.pack(pady=20)
        
    def generate_vehicle_activity_report(self, start_date, end_date):
        # Get vehicle activity
        data = self.db_manager.fetch_all("""
        SELECT v.license_plate, v.model, COUNT(s.id) as trip_count
        FROM vehicles v
        LEFT JOIN schedules s ON v.id = s.vehicle_id AND s.departure_time BETWEEN ? AND ?
        GROUP BY v.id
        ORDER BY trip_count DESC
        """, (start_date, end_date))
        
        # Create report title
        title = ttk.Label(self.content_frame, text=f"Báo cáo Hoạt động Xe ({start_date} đến {end_date})", 
                         font=("Arial", 14, "bold"))
        title.pack(pady=10)
        
        # Create table frame
        table_frame = ttk.Frame(self.content_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, padx=10, pady=10)
        
        # Create table
        columns = ("license_plate", "model", "trip_count")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        
        # Format columns
        tree.column("license_plate", width=100, anchor=tk.W)
        tree.column("model", width=150, anchor=tk.W)
        tree.column("trip_count", width=100, anchor=tk.E)
        
        # Create headings
        tree.heading("license_plate", text="Biển số")
        tree.heading("model", text="Mẫu xe")
        tree.heading("trip_count", text="Số chuyến")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Add data to table
        for item in data:
            tree.insert("", tk.END, values=(item['license_plate'], item['model'], item['trip_count']))
        
        # Create chart frame
        chart_frame = ttk.Frame(self.content_frame)
        chart_frame.pack(fill=tk.BOTH, expand=True, side=tk.RIGHT, padx=10, pady=10)
        
        # Create chart
        if data:
            try:
                fig, ax = plt.subplots(figsize=(6, 4))
                
                license_plates = [item['license_plate'] for item in data]
                trip_counts = [item['trip_count'] for item in data]
                
                # Create horizontal bar chart
                bars = ax.barh(license_plates, trip_counts)
                
                # Add labels
                ax.set_title('Số chuyến theo Xe')
                ax.set_xlabel('Số chuyến')
                ax.set_ylabel('Biển số xe')
                
                # Add value labels
                for bar in bars:
                    width = bar.get_width()
                    ax.text(width, bar.get_y() + bar.get_height()/2.,
                           f'{width}',
                           ha='left', va='center')
                
                # Adjust layout
                plt.tight_layout()
                
                # Create canvas
                canvas = FigureCanvasTkAgg(fig, master=chart_frame)
                canvas.draw()
                canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            except Exception as e:
                error_label = ttk.Label(chart_frame, text=f"Không thể tạo biểu đồ: {str(e)}", 
                                      foreground="red")
                error_label.pack(pady=20)
        else:
            no_data_label = ttk.Label(chart_frame, text="Không có dữ liệu để hiển thị biểu đồ", 
                                    font=("Arial", 12))
            no_data_label.pack(pady=20)
        
    def generate_driver_activity_report(self, start_date, end_date):
        # Get driver activity
        data = self.db_manager.fetch_all("""
        SELECT d.name, COUNT(s.id) as trip_count
        FROM drivers d
        LEFT JOIN schedules s ON d.id = s.driver_id AND s.departure_time BETWEEN ? AND ?
        GROUP BY d.id
        ORDER BY trip_count DESC
        """, (start_date, end_date))
        
        # Create report title
        title = ttk.Label(self.content_frame, text=f"Báo cáo Hoạt động Tài xế ({start_date} đến {end_date})", 
                         font=("Arial", 14, "bold"))
        title.pack(pady=10)
        
        # Create table frame
        table_frame = ttk.Frame(self.content_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, padx=10, pady=10)
        
        # Create table
        columns = ("name", "trip_count")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        
        # Format columns
        tree.column("name", width=200, anchor=tk.W)
        tree.column("trip_count", width=100, anchor=tk.E)
        
        # Create headings
        tree.heading("name", text="Tài xế")
        tree.heading("trip_count", text="Số chuyến")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Add data to table
        for item in data:
            tree.insert("", tk.END, values=(item['name'], item['trip_count']))
        
        # Create chart frame
        chart_frame = ttk.Frame(self.content_frame)
        chart_frame.pack(fill=tk.BOTH, expand=True, side=tk.RIGHT, padx=10, pady=10)
        
        # Create chart
        if data:
            try:
                fig, ax = plt.subplots(figsize=(6, 4))
                
                names = [item['name'] for item in data]
                trip_counts = [item['trip_count'] for item in data]
                
                # Create horizontal bar chart
                bars = ax.barh(names, trip_counts)
                
                # Add labels
                ax.set_title('Số chuyến theo Tài xế')
                ax.set_xlabel('Số chuyến')
                ax.set_ylabel('Tài xế')
                
                # Add value labels
                for bar in bars:
                    width = bar.get_width()
                    ax.text(width, bar.get_y() + bar.get_height()/2.,
                           f'{width}',
                           ha='left', va='center')
                
                # Adjust layout
                plt.tight_layout()
                
                # Create canvas
                canvas = FigureCanvasTkAgg(fig, master=chart_frame)
                canvas.draw()
                canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            except Exception as e:
                error_label = ttk.Label(chart_frame, text=f"Không thể tạo biểu đồ: {str(e)}", 
                                      foreground="red")
                error_label.pack(pady=20)
        else:
            no_data_label = ttk.Label(chart_frame, text="Không có dữ liệu để hiển thị biểu đồ", 
                                    font=("Arial", 12))
            no_data_label.pack(pady=20)
