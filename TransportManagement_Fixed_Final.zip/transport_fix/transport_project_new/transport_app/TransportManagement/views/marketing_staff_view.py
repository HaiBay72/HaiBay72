import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import re
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class MarketingStaffView(ttk.Frame):
    def __init__(self, parent, db_manager, current_user=None):
        super().__init__(parent)
        self.parent = parent
        self.db_manager = db_manager
        self.current_user = current_user
        
        # Configure style
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Arial", 18, "bold"))
        
        # Create main layout
        self.create_widgets()
        
        # Load data
        self.load_data()
        
    def create_widgets(self):
        # Create header frame
        header_frame = ttk.Frame(self)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Add title
        title = ttk.Label(header_frame, text="Quản lý Nhân viên Tiếp thị", style="Title.TLabel")
        title.pack(side=tk.LEFT)
        
        # Add search frame
        search_frame = ttk.Frame(header_frame)
        search_frame.pack(side=tk.RIGHT, padx=5)
        
        # Add search entry
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=20)
        search_entry.pack(side=tk.LEFT, padx=5)
        
        # Add search button
        search_button = ttk.Button(search_frame, text="Tìm kiếm", command=self.search_marketing_staff)
        search_button.pack(side=tk.LEFT)
        
        # Add buttons
        button_frame = ttk.Frame(header_frame)
        button_frame.pack(side=tk.RIGHT)
        
        # Check if user has admin role to show add/edit/delete buttons
        is_admin = self.current_user and self.current_user['role'] == 'admin'
        
        if is_admin:
            # Add button
            self.add_button = ttk.Button(button_frame, text="Thêm Nhân viên", command=self.add_marketing_staff)
            self.add_button.pack(side=tk.LEFT, padx=5)
            
            # Edit button
            self.edit_button = ttk.Button(button_frame, text="Sửa", command=self.edit_marketing_staff)
            self.edit_button.pack(side=tk.LEFT, padx=5)
            
            # Delete button
            self.delete_button = ttk.Button(button_frame, text="Xóa", command=self.delete_marketing_staff)
            self.delete_button.pack(side=tk.LEFT, padx=5)
        
        # Create table
        self.create_table()
        
    def create_table(self):
        # Create a frame for the table
        table_frame = ttk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create treeview
        self.tree = ttk.Treeview(table_frame, yscrollcommand=scrollbar.set)
        
        # Configure scrollbar
        scrollbar.config(command=self.tree.yview)
        
        # Define columns
        self.tree["columns"] = ("name", "phone", "join_date", "status", "notes")
        
        # Format columns
        self.tree.column("#0", width=50, stretch=tk.NO)
        self.tree.column("name", width=150, anchor=tk.W)
        self.tree.column("phone", width=100, anchor=tk.W)
        self.tree.column("join_date", width=100, anchor=tk.W)
        self.tree.column("status", width=100, anchor=tk.W)
        self.tree.column("notes", width=300, anchor=tk.W)
        
        # Create headings
        self.tree.heading("#0", text="ID")
        self.tree.heading("name", text="Họ tên")
        self.tree.heading("phone", text="Điện thoại")
        self.tree.heading("join_date", text="Ngày vào làm")
        self.tree.heading("status", text="Trạng thái")
        self.tree.heading("notes", text="Ghi chú")
        
        # Pack the treeview
        self.tree.pack(fill=tk.BOTH, expand=True)
        
    def load_data(self, search_term=None):
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Get all marketing staff
            if search_term:
                staff = self.db_manager.fetch_all("""
                SELECT * FROM employees 
                WHERE employee_type = 'marketing' AND (name LIKE ? OR phone LIKE ?)
                ORDER BY id
                """, (f"%{search_term}%", f"%{search_term}%"))
            else:
                staff = self.db_manager.fetch_all("""
                SELECT * FROM employees 
                WHERE employee_type = 'marketing'
                ORDER BY id
                """)
            
            # Add data to treeview
            for employee in staff:
                # Safely access fields with fallback to empty string
                join_date = employee['join_date'] if 'join_date' in employee and employee['join_date'] is not None else ''
                notes = employee['notes'] if 'notes' in employee and employee['notes'] is not None else ''
                
                self.tree.insert("", tk.END, text=employee['id'],
                               values=(employee['name'], 
                                      employee['phone'],
                                      join_date,
                                      employee['status'],
                                      notes))
        except Exception as e:
            messagebox.showerror("Lỗi Database", f"Không thể tải dữ liệu nhân viên tiếp thị: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
    
    def search_marketing_staff(self):
        # Get search term
        search_term = self.search_var.get()
        
        # Load data with search term
        self.load_data(search_term)
        
    def add_marketing_staff(self):
        # Create dialog window
        self.dialog = tk.Toplevel(self)
        self.dialog.title("Thêm Nhân viên Tiếp thị Mới")
        self.dialog.geometry("400x400")
        self.dialog.resizable(False, False)
        self.dialog.transient(self)
        self.dialog.grab_set()
        
        # Create form
        self.create_marketing_staff_form()
        
        # Add buttons
        button_frame = ttk.Frame(self.dialog)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Save button
        save_button = ttk.Button(button_frame, text="Lưu", command=self.save_marketing_staff)
        save_button.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Hủy", command=self.dialog.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=5)
        
    def create_marketing_staff_form(self):
        # Create form frame
        form_frame = ttk.Frame(self.dialog, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        # Name
        ttk.Label(form_frame, text="Họ tên:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.name_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.name_var, width=30).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        # Phone
        ttk.Label(form_frame, text="Điện thoại:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.phone_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.phone_var, width=30).grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Join date
        ttk.Label(form_frame, text="Ngày vào làm:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.join_date_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.join_date_var, width=30).grid(row=2, column=1, sticky=tk.W, pady=5)
        ttk.Label(form_frame, text="(YYYY-MM-DD)").grid(row=2, column=2, sticky=tk.W, pady=5)
        
        # Status
        ttk.Label(form_frame, text="Trạng thái:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.status_var = tk.StringVar()
        status_combo = ttk.Combobox(form_frame, textvariable=self.status_var, width=27)
        status_combo['values'] = ('Hoạt động', 'Nghỉ phép', 'Nghỉ việc')
        status_combo.current(0)
        status_combo.grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Notes
        ttk.Label(form_frame, text="Ghi chú:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.notes_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.notes_var, width=30).grid(row=4, column=1, sticky=tk.W, pady=5)
        
        # Set default values for edit mode
        if hasattr(self, 'edit_id'):
            # Connect to database
            self.db_manager.connect()
            
            try:
                # Get marketing staff data
                staff = self.db_manager.fetch_one("SELECT * FROM employees WHERE id = ? AND employee_type = 'marketing'", (self.edit_id,))
                
                if staff:
                    # Set form values
                    self.name_var.set(staff['name'])
                    self.phone_var.set(staff['phone'])
                    
                    # Safely set join_date
                    if 'join_date' in staff and staff['join_date'] is not None:
                        self.join_date_var.set(staff['join_date'])
                    else:
                        self.join_date_var.set("")
                        
                    self.status_var.set(staff['status'])
                    
                    # Safely set notes
                    if 'notes' in staff and staff['notes'] is not None:
                        self.notes_var.set(staff['notes'])
                    else:
                        self.notes_var.set("")
            except Exception as e:
                messagebox.showerror("Lỗi Database", f"Không thể tải thông tin nhân viên tiếp thị: {str(e)}")
            finally:
                # Close database connection
                self.db_manager.close()
    
    def save_marketing_staff(self):
        # Get form data
        name = self.name_var.get()
        phone = self.phone_var.get()
        join_date = self.join_date_var.get()
        status = self.status_var.get()
        notes = self.notes_var.get()
        
        # Validate data
        validation_errors = []
        
        # Validate required fields
        if not name:
            validation_errors.append("Họ tên không được để trống!")
        if not phone:
            validation_errors.append("Số điện thoại không được để trống!")
        if not status:
            validation_errors.append("Trạng thái không được để trống!")
        
        # Validate phone number format
        if phone and not re.match(r'^0\d{9,10}$', phone):
            validation_errors.append("Số điện thoại không hợp lệ! Định dạng: 0XXXXXXXXX (10-11 số)")
        
        # Validate date format if provided
        if join_date:
            try:
                datetime.strptime(join_date, '%Y-%m-%d')
            except ValueError:
                validation_errors.append("Ngày vào làm không hợp lệ! Định dạng: YYYY-MM-DD")
        
        # Show validation errors if any
        if validation_errors:
            messagebox.showerror("Lỗi", "\n".join(validation_errors))
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if in edit mode
            if hasattr(self, 'edit_id'):
                # Update marketing staff
                self.db_manager.execute("""
                UPDATE employees 
                SET name = ?, phone = ?, join_date = ?, status = ?, notes = ? 
                WHERE id = ?
                """, (name, phone, join_date, status, notes, self.edit_id))
                
                # Show success message
                messagebox.showinfo("Thành công", "Cập nhật thông tin nhân viên tiếp thị thành công!")
                
                # Remove edit_id attribute
                delattr(self, 'edit_id')
            else:
                # Insert new marketing staff
                self.db_manager.execute("""
                INSERT INTO employees (name, phone, employee_type, join_date, status, notes)
                VALUES (?, ?, 'marketing', ?, ?, ?)
                """, (name, phone, join_date, status, notes))
                
                # Show success message
                messagebox.showinfo("Thành công", "Thêm nhân viên tiếp thị mới thành công!")
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể lưu thông tin nhân viên tiếp thị: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Close dialog
            self.dialog.destroy()
            
            # Reload data
            self.load_data()
        
    def edit_marketing_staff(self):
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn nhân viên tiếp thị cần sửa!")
            return
        
        # Get marketing staff ID
        self.edit_id = int(self.tree.item(selected_item[0], "text"))
        
        # Open add dialog in edit mode
        self.add_marketing_staff()
        
        # Change dialog title
        self.dialog.title("Sửa Thông tin Nhân viên Tiếp thị")
        
    def delete_marketing_staff(self):
        # Check if user has admin role
        if not self.current_user or self.current_user['role'] != 'admin':
            messagebox.showerror("Lỗi", "Bạn không có quyền xóa nhân viên tiếp thị!")
            return
            
        # Get selected item
        selected_item = self.tree.selection()
        
        if not selected_item:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn nhân viên tiếp thị cần xóa!")
            return
        
        # Get marketing staff ID
        staff_id = int(self.tree.item(selected_item[0], "text"))
        
        # Confirm deletion
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc chắn muốn xóa nhân viên tiếp thị này?"):
            return
        
        # Connect to database
        self.db_manager.connect()
        
        try:
            # Check if marketing staff is assigned to any schedules
            schedules = self.db_manager.fetch_all("SELECT id FROM schedules WHERE marketing_staff_id = ?", (staff_id,))
            
            if schedules:
                messagebox.showerror("Lỗi", "Không thể xóa nhân viên tiếp thị này vì đã được gán cho lịch trình!")
                return
            
            # Delete marketing staff
            self.db_manager.execute("DELETE FROM employees WHERE id = ?", (staff_id,))
            
            # Show success message
            messagebox.showinfo("Thành công", "Xóa nhân viên tiếp thị thành công!")
            
            # Reorder IDs after deletion
            self.reorder_marketing_staff_ids()
            
        except Exception as e:
            # Show error message
            messagebox.showerror("Lỗi", f"Không thể xóa nhân viên tiếp thị: {str(e)}")
        finally:
            # Close database connection
            self.db_manager.close()
            
            # Reload data
            self.load_data()
    
    def reorder_marketing_staff_ids(self):
        """Reorder marketing staff IDs after deletion to maintain sequential order"""
        try:
            # Get all marketing staff ordered by ID
            staff = self.db_manager.fetch_all("SELECT id FROM employees WHERE employee_type = 'marketing' ORDER BY id")
            
            # Create temporary table
            self.db_manager.execute("CREATE TABLE employees_temp AS SELECT * FROM employees")
            
            # Drop original table
            self.db_manager.execute("DROP TABLE employees")
            
            # Recreate original table
            self.db_manager.execute('''
            CREATE TABLE employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT NOT NULL,
                employee_type TEXT NOT NULL,
                license_number TEXT,
                license_type TEXT,
                join_date TEXT,
                status TEXT NOT NULL,
                notes TEXT
            )
            ''')
            
            # Insert data back with new IDs
            self.db_manager.execute("""
            INSERT INTO employees (name, phone, employee_type, license_number, license_type, 
                                  join_date, status, notes)
            SELECT name, phone, employee_type, license_number, license_type, 
                   join_date, status, notes
            FROM employees_temp
            ORDER BY id
            """)
            
            # Drop temporary table
            self.db_manager.execute("DROP TABLE employees_temp")
            
            # Update references in schedules table
            schedules = self.db_manager.fetch_all("SELECT id, marketing_staff_id FROM schedules WHERE marketing_staff_id IS NOT NULL")
            
            # Create mapping of old IDs to new IDs
            id_mapping = {}
            new_staff = self.db_manager.fetch_all("SELECT id FROM employees WHERE employee_type = 'marketing' ORDER BY id")
            
            for i, employee in enumerate(staff):
                if i < len(new_staff):
                    id_mapping[employee['id']] = new_staff[i]['id']
            
            # Update schedules with new IDs
            for schedule in schedules:
                staff_id = schedule['marketing_staff_id']
                new_staff_id = id_mapping.get(staff_id, staff_id)
                
                self.db_manager.execute("""
                UPDATE schedules 
                SET marketing_staff_id = ? 
                WHERE id = ?
                """, (new_staff_id, schedule['id']))
                
            # Update references in users table
            users = self.db_manager.fetch_all("SELECT id, employee_id FROM users WHERE employee_id IS NOT NULL")
            
            # Update users with new IDs
            for user in users:
                employee_id = user['employee_id']
                new_employee_id = id_mapping.get(employee_id, employee_id)
                
                self.db_manager.execute("""
                UPDATE users 
                SET employee_id = ? 
                WHERE id = ?
                """, (new_employee_id, user['id']))
                
        except Exception as e:
            print(f"Error reordering marketing staff IDs: {str(e)}")
            # Rollback transaction in case of error
            if self.db_manager.connection:
                self.db_manager.connection.rollback()
