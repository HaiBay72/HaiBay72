"""
This script is used to package the Transport Management application into a Windows executable.
It uses PyInstaller to create a standalone executable that can be run on Windows without
requiring Python or any dependencies to be installed.

Usage:
    python setup.py

This will create a 'dist' directory containing the executable file.
"""

import PyInstaller.__main__
import os
import shutil
import sys

# Get the directory of the current file
current_dir = os.path.dirname(os.path.abspath(__file__))

# Define paths
resources_dir = os.path.join(current_dir, 'resources')
images_dir = os.path.join(resources_dir, 'images')

# Create resources directory if it doesn't exist
os.makedirs(images_dir, exist_ok=True)

# Define PyInstaller arguments
pyinstaller_args = [
    'main.py',                                  # Script to package
    '--name=TransportManagement',               # Name of the executable
    '--onefile',                                # Create a single executable file
    '--windowed',                               # Do not show console window
    '--add-data=resources;resources',           # Include resources directory
    '--icon=resources/images/bus_icon.png',     # Set icon for the executable
    '--clean',                                  # Clean PyInstaller cache
    '--noconfirm',                              # Replace output directory without asking
]

# Run PyInstaller
PyInstaller.__main__.run(pyinstaller_args)

print("Packaging complete! The executable is in the 'dist' directory.")
