import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import database manager
from database.db_manager import DatabaseManager

# Import views
from views.login_view import LoginView
from views.main_window import MainWindow

class Application:
    def __init__(self, root):
        self.root = root
        self.root.title("Phần mềm Quản lý Vận tải")
        self.root.geometry("1200x700")
        self.root.minsize(800, 600)
        
        # Create database manager
        self.db_manager = DatabaseManager()
        
        # Initialize database
        self.initialize_database()
        
        # Show login screen
        self.show_login()
        
    def initialize_database(self):
        # Connect to database
        self.db_manager.connect()
        
        # Check if users table exists
        try:
            self.db_manager.fetch_one("SELECT 1 FROM users LIMIT 1")
        except:
            # If users table doesn't exist, run migration script
            self.db_manager.close()
            
            # Import and run migration script
            from scripts.db_migration import migrate_database
            migrate_database()
            
            # Reconnect to database
            self.db_manager.connect()
        
        # Close database connection
        self.db_manager.close()
        
    def show_login(self):
        # Create login view
        self.login_view = LoginView(self.root, self.db_manager, self.on_login_success)
        
    def on_login_success(self, user, employee):
        # Store user info
        self.current_user = user
        self.current_employee = employee
        
        # Create main window with user info
        self.main_window = MainWindow(self.root, self.db_manager, user, employee)

if __name__ == "__main__":
    # Create root window
    root = tk.Tk()
    
    # Create application
    app = Application(root)
    
    # Start main loop
    root.mainloop()
